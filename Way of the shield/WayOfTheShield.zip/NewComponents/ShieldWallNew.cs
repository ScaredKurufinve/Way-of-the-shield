﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kingmaker.UnitLogic;
using Kingmaker.RuleSystem.Rules;
using Kingmaker.Blueprints.Facts;
using Kingmaker.Blueprints.Items.Armors;
using UnityEngine;
using Kingmaker.Designers;
using Owlcat.Runtime.Core.Utils;

namespace Way_of_the_shield.NewComponents
{

    [AllowedOn(typeof(BlueprintUnitFact), false)]
    [AllowMultipleComponents]
    [TypeId("3ACCFF25E47344EB9A41426207E4E442")]
    public class ShieldWallNew : UnitFactComponentDelegate, ITargetRulebookHandler<RuleCalculateAC>
    {
        public BlueprintUnitFact ShieldWallFact
        {
            get
            {
                return m_ShieldWallFact?.Get();
            }
        }

        public void OnEventAboutToTrigger(RuleCalculateAC evt)
        {
            if (!Owner.Body.SecondaryHand.HasShield)
            {
                return;
            }
            int num = 0;
            IEnumerable<UnitEntityData> shielders = GameHelper.GetTargetsAround(Owner.Position, Radius, true, false)
                                                                .Where(unit => (unit != Owner
                                                                                && !unit.IsEnemy(Owner)
                                                                                && unit.Descriptor.HasFact(ShieldWallFact) || Owner.State.Features.SoloTactics)
                                                                                && unit.Body.SecondaryHand.HasShield
                                                                                && Vector3.Angle(Owner.OrientationDirection, unit.Position - Owner.Position) is >= 45 and <= 135);
            if (shielders.Count() == 0) return;
            IEnumerable<ArmorProficiencyGroup> leftSide = shielders.Where(shielder => Vector2.SignedAngle(Owner.OrientationDirection.To2D(), shielder.OrientationDirection.To2D()) is <= 115)
                                                              .Select(leftShielder => leftShielder.Body.SecondaryHand.Shield.Blueprint.Type.ProficiencyGroup);
            if (leftSide.Count() > 0)
            {
                if (leftSide.Any(shieldProf => shieldProf == ArmorProficiencyGroup.TowerShield)) num = +3;
                else if (leftSide.Any(shieldProf => shieldProf == ArmorProficiencyGroup.HeavyShield)) num = +2;
                else num++;
            }
            IEnumerable<ArmorProficiencyGroup> rightSide = shielders.Where(shielder => Vector2.SignedAngle(Owner.OrientationDirection.To2D(), shielder.OrientationDirection.To2D()) is >= 245)
                                                              .Select(rightShielder => rightShielder.Body.SecondaryHand.Shield.Blueprint.Type.ProficiencyGroup);
            if (rightSide.Count() > 0)
            {
                if (leftSide.Any(shieldProf => shieldProf == ArmorProficiencyGroup.TowerShield)) num = +3;
                else if (leftSide.Any(shieldProf => shieldProf == ArmorProficiencyGroup.HeavyShield)) num = +2;
                else num++;
            }
            evt.AddModifier(num, base.Fact, ModifierDescriptor.UntypedStackable);
        }
        public void OnEventDidTrigger(RuleCalculateAC evt)
        {
        }


        public BlueprintUnitFactReference m_ShieldWallFact;
        public int Radius;
    }
}
