﻿using Kingmaker.EntitySystem.Stats;
using Kingmaker.UnitLogic;
using Kingmaker.UnitLogic.Abilities.Components;
using Kingmaker.UnitLogic.Mechanics;
using Kingmaker.RuleSystem.Rules;

namespace Way_of_the_shield.NewComponents
{
    public class SavingBonusAgainstAlliesIfAllyHasFactAndSimpleProjectile : UnitFactComponentDelegate, IInitiatorRulebookHandler<RuleSavingThrow>
    {
        public void OnEventAboutToTrigger(RuleSavingThrow evt)
        {
            UnitEntityData caster = evt.Reason.Caster;
            //bool flag1 = caster is null;
            //bool flag2 = evt.Initiator == caster;
            //bool flag3 = !evt.Initiator.IsAlly(caster);
            //bool flag4 = EnablingFeature is not null && !caster.HasFact(EnablingFeature.Get());
            //bool flag5 = !(evt.Reason?.Ability?.AbilityDeliverProjectile?.Type != AbilityProjectileType.Cone);
            //Main.Comment.Log("Flag1 = {1}, flag2 = {2}, flag3 = {3}, flag4 = {4}, flag5 = {5}.", null, flag1, flag2, flag3, flag4, flag5);

            if (caster is null
                || evt.Initiator == caster
                || !evt.Initiator.IsAlly(caster)
                || savingThrowType != evt.Type
                || EnablingFeature is not null && !caster.HasFact(EnablingFeature.Get())
                || !(evt.Reason?.Ability?.AbilityDeliverProjectile?.Type != AbilityProjectileType.Cone)) return;
            int value = Bonus.Calculate(Context) + Value * Fact.GetRank();
            evt.AddModifier(value, Fact, ModifierDescriptor);
        }
        public void OnEventDidTrigger(RuleSavingThrow evt)
        {
        }

        public SavingThrowType savingThrowType;
        public ModifierDescriptor ModifierDescriptor;
        public int Value;
        public ContextValue Bonus;
        public BlueprintUnitFactReference EnablingFeature;
    }
}
