﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kingmaker.UnitLogic.Mechanics.Properties;
using Kingmaker.Items;
using Kingmaker.Items.Slots;
using Kingmaker.Designers;

namespace Way_of_the_shield.NewComponents
{
    public class TotalShieldBonusGetter : PropertyValueGetter
    {
        public override int GetBaseValue(UnitEntityData unit)
        {
            if (Way_of_the_shield.Settings.IsEnabled("Debug"))
                Main.Comment.Log("Inside the TotalShieldBonusGetter for {0}", unit.CharacterName);
            HandSlot offhand = unit?.Descriptor?.Body?.SecondaryHand;
            if (offhand is null || !offhand.HasShield)
            {
                return 0;
            }
            ItemEntityShield shield = offhand.MaybeShield;
            int num = shield.Blueprint.ArmorComponent.Type.ArmorBonus + GameHelper.GetItemEnhancementBonus(shield.ArmorComponent);
            if (Way_of_the_shield.Settings.IsEnabled("Debug")) 
                Main.Comment.Log("Total shield bonus is " + num);
            return num;
        }
    }
}
