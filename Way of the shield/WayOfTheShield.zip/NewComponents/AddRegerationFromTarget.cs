﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kingmaker.UnitLogic.Buffs.Blueprints;
using Kingmaker.RuleSystem.Rules.Damage;
using Kingmaker.UnitLogic;
using Kingmaker.UnitLogic.Buffs.Components;
using Kingmaker.UnitLogic.Buffs;
using RootMotion;
using Kingmaker.Controllers.Units;
using Kingmaker.Controllers;
using Kingmaker.Designers;
using Kingmaker;
using System.Reflection;
using Kingmaker.ElementsSystem;
using static Way_of_the_shield.Main;

namespace Way_of_the_shield.NewComponents
{
    public class AddRegerationFromTarget : AddEffectRegeneration, ITickEachRound
    {
        public bool m_checkCaster;
        public BlueprintBuffReference m_checkedFact;
        public BlueprintBuff CheckedFact
        {
            get
            {
                return m_checkedFact?.Get();
            }
        }
        
        public new void OnEventDidTrigger(RuleDealDamage evt)
        {
            Main.Comment.Log("Inside the Regeneration part.");
            if (evt.Target != base.Owner || evt.DamageBundle == null || this.Unremovable)
            {
                return;
            }
            BlueprintBuff b = CheckedFact;
            Main.Comment.Log("Checked fact is " + b?.name);
            if (b is null ) Suppress();
            UnitEntityData caster = Fact.MaybeContext.MaybeCaster;
            bool flag = m_checkCaster && caster is not null;
            foreach (Buff buff in evt.Initiator.Buffs)
            {
                Main.Comment.Log("Buff blueprint is {0}, it is{1} equal to the checked fact. Caster is {2}, is{3} equal to the context caster.",
                    buff.Blueprint.name, (buff.Blueprint == b ? "" : " not"), caster.CharacterName, (buff.Context.MaybeCaster == caster ? "" : " not"));
                if (buff.Blueprint == b && (flag && buff.Context.MaybeCaster == caster))
                {
                    Main.Comment.Log("Returning.");
                    return;
                }
            }
            Main.Comment.Log("Suppressing.");
            Suppress();
        }
        void ITickEachRound.OnNewRound()
        {
            if (Data is null)
            {
                Main.Comment.Error("Error! Data is null");
                return;
            }
            else Main.Comment.Log("Data is not null? " + (Data is not null));
            Main.Comment.Log("Timestamp is not null? " + (Data.SuppressTimestamp != null));
            if (Data.SuppressTimestamp != null && Game.Instance.TimeController.GameTime - Data.SuppressTimestamp >= 6f.Seconds())
            {
                Main.Comment.Log("1");
                Data.SuppressTimestamp = null;
                SetRegenerationActive(true);
            }
            if (Data.RegenerationActive && Owner.Damage > 0)
            {
                Main.Comment.Log("2");
                GameHelper.HealDamage(Owner, Owner, IsHalved ? (Heal / 2) : Heal, Fact);
            }
            Main.Comment.Log("3");
        }

    }

    [HarmonyPatch]
    public static class Check
    {
        [HarmonyTargetMethod]
        public static MethodBase Method()
        {
            return typeof(Buff).GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance).Where(m => m.Name.Contains("RunActionInContext")).FirstOrDefault();
        }
        [HarmonyPrefix]
        public static void Checker(Buff __instance, ActionList action, TargetWrapper target)
        {
            Comment.Log("Buff is " + __instance.Blueprint.name);
            Comment.Log("Owner is " + __instance.Owner.CharacterName);
            Comment.Log("Action is null? " + (action is null));
            Comment.Log("Target is null? " + (target is null));
            Comment.Log("Buff.Data is null?" + (ContextData<Buff.Data>.Request() is null));
            Comment.Log("Setup is null? " + (target is null));
            Comment.Log("Context is null? " + (__instance.Context is null));
            Comment.Log("DataScope is null? " + (__instance.Context.GetDataScope(target) is null));
        }
    }
}
