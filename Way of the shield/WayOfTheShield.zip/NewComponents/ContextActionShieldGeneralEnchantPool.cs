﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kingmaker.UnitLogic.ActivatableAbilities;
using Kingmaker.UnitLogic.FactLogic;
using Kingmaker.UnitLogic.Mechanics;
using Kingmaker.UnitLogic.Mechanics.Actions;
using UnityEngine.Serialization;
using UnityEngine;
using Kingmaker.Blueprints.Items.Ecnchantments;
using Kingmaker.Designers;
using Kingmaker.Items;
using Kingmaker.UnitLogic.Parts;
using Owlcat.Runtime.Core.Logging;

namespace Way_of_the_shield.NewComponents
{
    [TypeId("1fe5b88460f04fa2873b0c421b77e31b")]
    public class ContextActionShieldGeneralEnchantPool : ContextAction
    {
        public EnchantPoolType EnchantPool;
        public ActivatableAbilityGroup Group;
        [SerializeField]
        [FormerlySerializedAs("DefaultEnchantmentsWeapon")]
        public BlueprintWeaponEnchantmentReference[] m_DefaultEnchantmentsWeapon = new BlueprintWeaponEnchantmentReference[6];
        public ReferenceArrayProxy<BlueprintWeaponEnchantment, BlueprintWeaponEnchantmentReference> DefaultEnchantmentsWeapon
        {
            get
            {
                return m_DefaultEnchantmentsWeapon;
            }
        }
        [SerializeField]
        [FormerlySerializedAs("DefaultEnchantmentsArmor")]
        public BlueprintArmorEnchantmentReference[] m_DefaultEnchantmentsArmor = new BlueprintArmorEnchantmentReference[6];
        public ReferenceArrayProxy<BlueprintArmorEnchantment, BlueprintArmorEnchantmentReference> DefaultEnchantmentsArmor
        {
            get
            {
                return m_DefaultEnchantmentsArmor;
            }
        }

        public ContextDurationValue DurationValue;
        public override string GetCaption()
        {
            return string.Format("Add enchants from pool to caster's shield (for {0})", DurationValue);
        }
        public override void RunAction()
        {
            UnitEntityData maybeCaster = Context.MaybeCaster;
            if (maybeCaster == null)
            {
                LogChannel.Default.Error(this, "ContextActionShieldWeaponEnchantPool: target is null", Array.Empty<object>());
                return;
            }
            UnitPartEnchantPoolData unitPartEnchantPoolData = maybeCaster.Ensure<UnitPartEnchantPoolData>();
            unitPartEnchantPoolData.ClearEnchantPool(EnchantPool);
            ItemEntityShield maybeShield = maybeCaster.Body.SecondaryHand.MaybeShield;
            if (maybeShield is null)
            {
                return;
            }
            ItemEntityWeapon itemEntityWeapon = maybeShield.WeaponComponent;
            ItemEntityArmor itemEntityArmor = maybeShield.ArmorComponent;
            int num = maybeCaster.Ensure<UnitPartActivatableAbility>().GetGroupSize(Group);
            if (itemEntityWeapon.Enchantments.Any())
            {
                num += GameHelper.GetItemEnhancementBonus(itemEntityWeapon);
            }
            Rounds duration = DurationValue.Calculate(Context);
            BlueprintItemEnchantment enchant;
            foreach (AddBondProperty addBondProperty in maybeCaster.Buffs.SelectFactComponents<AddBondProperty>())
            {
                if (addBondProperty.EnchantPool != EnchantPool) continue;
                enchant = addBondProperty.Enchant;
                if (enchant.EnchantmentCost > num) continue;
                if (enchant is BlueprintWeaponEnchantment && itemEntityWeapon is not null && !itemEntityWeapon.HasEnchantment(enchant))
                    unitPartEnchantPoolData.AddEnchant(itemEntityWeapon, EnchantPool, enchant, Context, duration);
                else if (enchant is BlueprintArmorEnchantment && itemEntityArmor is not null && !itemEntityArmor.HasEnchantment(enchant))
                    unitPartEnchantPoolData.AddEnchant(itemEntityArmor, EnchantPool, enchant, Context, duration);
                else if (enchant is BlueprintEquipmentEnchantment && !maybeShield.HasEnchantment(enchant))
                    unitPartEnchantPoolData.AddEnchant(maybeShield, EnchantPool, enchant, Context, duration);
                 
                num -= addBondProperty.Enchant.EnchantmentCost;
                if (num <= 0) break;
            }
            int num2 = Math.Min(6, num);
            num2--;
            bool weapon = false || itemEntityWeapon is null;
            bool armor = false || itemEntityArmor is null;
            while (num2 >= 0 && (weapon is false || armor is false))
            {
                BlueprintWeaponEnchantment enchantmentWeapon = DefaultEnchantmentsWeapon[num2];
                if (!weapon && enchantmentWeapon is not null)
                {
                    unitPartEnchantPoolData.AddEnchant(itemEntityWeapon, this.EnchantPool, enchantmentWeapon, base.Context, duration);
                    weapon = true;
                }
                BlueprintArmorEnchantment enchantmentArmor = DefaultEnchantmentsArmor[num2];
                if (!armor && enchantmentWeapon is not null)
                {
                    unitPartEnchantPoolData.AddEnchant(itemEntityArmor, this.EnchantPool, enchantmentArmor, base.Context, duration);
                    weapon = true;
                }
                num2--;
            }
        }
    }
}
