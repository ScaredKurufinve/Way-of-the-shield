﻿using System.Collections.Generic;
using Kingmaker.UnitLogic.Abilities;
using Kingmaker.UnitLogic.Abilities.Components.Base;
using static Way_of_the_shield.Main;

namespace Way_of_the_shield.NewComponents
{
    public class AbilityDeliverTurnTo : AbilityCustomLogic
    {
        public override IEnumerator<AbilityDeliveryTarget> Deliver(AbilityExecutionContext context, TargetWrapper target)
        {
            Comment.Log("Delivering AbilityDeliverTurnTo. Caster is {0}. Current orientation is {1}, target position is {2}.", new object[] { context.Caster?.CharacterName, context.Caster?.OrientationDirection, target.Point });
            context.Caster?.ForceLookAt(target.Point);
            yield return null;

        }
        public override void Cleanup(AbilityExecutionContext context)
        {
        }
    }
}
