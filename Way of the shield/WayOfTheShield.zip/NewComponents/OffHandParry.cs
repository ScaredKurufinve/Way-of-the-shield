﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using Kingmaker;
using Kingmaker.Blueprints.Facts;
using Kingmaker.Blueprints.Items.Shields;
using Kingmaker.Blueprints.Items.Weapons;
using Kingmaker.Designers.Mechanics.Facts;
using Kingmaker.EntitySystem.Stats;
using Kingmaker.Items;
using Kingmaker.Blueprints.Items.Armors;
using Kingmaker.Items.Slots;
using Kingmaker.RuleSystem.Rules;
using Kingmaker.UI.ServiceWindow;
using Kingmaker.UI.MVVM._VM.ServiceWindows.Inventory;
using Kingmaker.UI.MVVM._VM.Slots;
using Kingmaker.UnitLogic;
using Kingmaker.UnitLogic.Commands;

namespace Way_of_the_shield.NewComponents
{
    public static class OffHandParry
    {
        public static BlueprintItemWeapon LightShieldWeapon = ResourcesLibrary.TryGetBlueprint<BlueprintItemWeapon>("62c90581f9892e9468f0d8229c7321c4");


        public class OffHandParryUnitPart : OldStyleUnitPart, ITargetRulebookHandler<RuleAttackRoll>, IInventoryHandler
        {
            public WeaponCategory? Category;
            public bool activated;
            public bool riposte;

            public static bool flag = false;
            public ItemEntityWeapon weapon;
            public bool HasParries;

            IEnumerator<int> parries;

            public void TryActivate(WeaponCategory category, bool counterattack)
            {
                Main.Comment.Log("Trying to activate OffHand Parry part with " + category + " category.");
                flag = true;
                ItemEntityWeapon w = Owner?.Body?.SecondaryHand.MaybeWeapon;
                if (w is null) Main.Comment.Log("Weapon is Null");
                else Main.Comment.Log("Weapon category is " + w.Blueprint.Type.Category);
                if (w?.Blueprint.Type.Category == category)
                {
                    Category = category;
                    parries = UnitAttack.EnumerateAttacks(Rulebook.Trigger(new RuleCalculateAttacksCount(Owner)).Result.SecondaryHand);
                    weapon = w;
                    riposte = counterattack;
                    IEnumerator<int> parries2 = UnitAttack.EnumerateAttacks(Rulebook.Trigger(new RuleCalculateAttacksCount(Owner)).Result.SecondaryHand);
                    int n = 0;
                    while (parries2.MoveNext())
                    {
                        n++;
                    }
                    Main.Comment.Log("Amount of parries is " + n);
                    Owner.Unit.Ensure<MechanicsFeatureExtension.MechanicsFeatureExtensionPart>().ShieldDenied.Retain();
                    activated = true;
                }
                //if (Settings.IsEnabled("Debug")
                if (activated) Main.Comment.Log("Activated is " + activated);
                flag = false;
                HasParries = parries.MoveNext();
            }

            public void TryDeactivate(WeaponCategory category)
            {
                flag = true;
                if (Owner?.Body?.SecondaryHand.MaybeWeapon?.Blueprint.Type.Category == category)
                {
                    Category = null;
                    parries = null;
                    riposte = false;
                    Owner.Unit.Get<MechanicsFeatureExtension.MechanicsFeatureExtensionPart>()?.ShieldDenied.Release();
                    activated = false;
                    //if (Settings.IsEnabled("Debug")
                    Main.Comment.Log("OffHand Parry part is deactivated through TryDeactivate call.");
                }
                flag = false;
            }

            public void OnEventAboutToTrigger(RuleAttackRoll evt)
            {
                Main.Comment.Log("OffHand Parry noticed the incoming attack.");
                if (!evt.Weapon.Blueprint.IsMelee || evt.Parry != null || !activated
                    || !Owner.State.CanAct
                    || Rulebook.Trigger<RuleCheckTargetFlatFooted>(new(evt.Initiator, evt.Target)).IsFlatFooted // code out later
                    || !HasParries)
                    return;

                Main.Comment.Log("OffHand Parry part of " + Owner.CharacterName + " is triggered. Attacker is " + evt.Initiator.CharacterName + ", weapon is " + evt.Weapon.Name + ".");
                evt.TryParry(Owner, weapon, parries.Current);
                Main.Comment.Log("OffHand Parry part of " + Owner.CharacterName + " wishes to parry.");
                ModifiableValue additionalAttackBonus = Owner.Stats.AdditionalAttackBonus;
                int num = evt.Initiator.Descriptor.State.Size - Owner.State.Size;
                if (num > 0)
                {
                    int value = -4 * num;
                    evt.AddTemporaryModifier(additionalAttackBonus.AddModifier(value, ModifierDescriptor.Penalty));
                }

            }

            public void OnEventDidTrigger(RuleAttackRoll evt)
            {
                RuleAttackRoll.ParryData parry = evt.Parry;
                if (parry != null
                    && parry.Initiator == Owner
                    && activated
                    && parry.IsTriggered)
                {
                    HasParries = parries.MoveNext();
                    Main.Comment.Log(parry.Initiator.CharacterName + " parried the attack of " + evt.Initiator.CharacterName + ". Attempted to move the parry enumerator.");
                    if (evt.Result == AttackResult.Parried && riposte == true)
                        Game.Instance.CombatEngagementController.ForceAttackOfOpportunity(Owner, evt.Initiator, false);
                }
            }

            public void Refresh()
            {
                Main.Comment.Log("Inventory refresh is noticed by OffHandParry part of " + Owner.CharacterName + ".");
                if (Owner?.Body?.SecondaryHand.MaybeWeapon == weapon) return;

                Category = null;
                parries = null;
                activated = false;
                riposte = false;
                Main.Comment.Log("OffHandParry part of " + Owner.CharacterName + " is deactivated due to inventory refreshment.");
            }

            public void TryEquip(ItemSlotVM slot)
            {

            }
            public void TryDrop(ItemSlotVM slot)
            {

            }

        }


        [AllowedOn(typeof(BlueprintUnitFact), false)]
        [TypeId("ba113232f466438cadd7263f03a536be")]
        public class OffHandParryComponent : UnitFactComponentDelegate

        {
            public WeaponCategory category;
            public bool riposte = false;


            public override void OnTurnOn()
            {
                if (Settings.IsEnabled("Debug"))
                    Main.Comment.Log("OffHandParryComponent of " + Owner.CharacterName + " is being turned on.");
                OffHandParryUnitPart part = Owner.Parts.Ensure<OffHandParryUnitPart>();
                if (Settings.IsEnabled("Debug"))
                    Main.Comment.Log("OffHandParry part activate state is" + part.activated);
                if (part.activated == true) return;
                part.TryActivate(category, riposte);
            }

            public override void OnTurnOff()
            {
                Main.Comment.Log("OffHandParryComponent of " + Owner.CharacterName + " is being turned off.");
                Owner.Parts.Get<OffHandParryUnitPart>()?.TryDeactivate(category);
            }

        }

        [HarmonyPatch(typeof(RuleCalculateAttacksCount), nameof(RuleCalculateAttacksCount.OnTrigger))]
        public static class RuleCalculateAttacksCount_OnTrigger_patch
        {

            [HarmonyPostfix]
            public static void Postfix(RuleCalculateAttacksCount __instance)
            {
                OffHandParryUnitPart part = __instance.Initiator?.Parts.Get<OffHandParryUnitPart>();
                if (part is not null && part.activated)
                {
                    RuleCalculateAttacksCount.AttacksCount result = __instance.Result.SecondaryHand;
                    result.AdditionalAttacks = 0;
                    result.HasteAttacks = 0;
                    result.PenalizedAttacks = 0;
                }
            }


            [HarmonyTranspiler]
            public static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
            {
                Main.Comment.Log("Entered RuleCalculateAttacksCount OnTrigger transpiler");
                List<CodeInstruction> _instructions = instructions.ToList();

                CodeInstruction[] toSearch =
                    new CodeInstruction[]
                    {
                        new CodeInstruction(OpCodes.Ldfld, typeof(UnitDescriptor).GetField(nameof(UnitDescriptor.State))),
                        new CodeInstruction(OpCodes.Ldfld, typeof(UnitState).GetField(nameof(UnitState.Features))),
                        new CodeInstruction(OpCodes.Ldfld, typeof(UnitMechanicFeatures).GetField(nameof(UnitMechanicFeatures.ShieldBash))),
                        new CodeInstruction(OpCodes.Call),
                        new CodeInstruction(OpCodes.Brtrue_S)
                    };

                int index = Utilities.IndexFinder(instructions, toSearch);
                if (index == -1) { Main.Comment.Log("Failed to find index of Initiator.State.Features.ShieldBash"); return instructions; };

                CodeInstruction[] toInsert =
                    new CodeInstruction[]
                    {
                        new CodeInstruction(OpCodes.Ldsfld, typeof(OffHandParryUnitPart).GetField(nameof(OffHandParryUnitPart.flag))),
                        new CodeInstruction(OpCodes.Brtrue_S, _instructions[index -1].operand)
                    };
                _instructions.InsertRange(index, toInsert);
                _instructions.InsertRange(index - 1,
                    new CodeInstruction[]
                    {
                        new CodeInstruction (OpCodes.Ldarg_0),
                        CodeInstruction.Call(typeof(OffHandParry), nameof(OffHandParry.BucklerOrBash))
                    });

                foreach (CodeInstruction i in _instructions) Main.Comment.Log(i.ToString());
                return _instructions;

            }

            [HarmonyPatch(nameof(RuleCalculateAttacksCount.AddExtraAttacks))]
            [HarmonyTranspiler]
            public static IEnumerable<CodeInstruction> Transpiler2(IEnumerable<CodeInstruction> instructions)
            {
                Main.Comment.Log("Entered RuleCalculateAttacksCount AddExtraAttacks transpiler");
                List<CodeInstruction> _instructions = instructions.ToList();

                CodeInstruction[] toSearch =
                    new CodeInstruction[]
                    {
                        new CodeInstruction(OpCodes.Ldfld, typeof(UnitDescriptor).GetField(nameof(UnitDescriptor.State))),
                        new CodeInstruction(OpCodes.Ldfld, typeof(UnitState).GetField(nameof(UnitState.Features))),
                        new CodeInstruction(OpCodes.Ldfld, typeof(UnitMechanicFeatures).GetField(nameof(UnitMechanicFeatures.ShieldBash))),
                        new CodeInstruction(OpCodes.Call),
                        new CodeInstruction(OpCodes.Brtrue_S)
                    };

                int index = Utilities.IndexFinder(instructions, toSearch);
                if (index == -1) { Main.Comment.Log("Failed to find index of Initiator.State.Features.ShieldBash"); return instructions; };

                _instructions.InsertRange(index - 1,
                    new CodeInstruction[]
                    {
                        new CodeInstruction (OpCodes.Ldarg_0),
                        CodeInstruction.Call(typeof(OffHandParry), nameof(OffHandParry.BucklerOrBash))
                    });

                foreach (CodeInstruction i in _instructions) Main.Comment.Log(i.ToString());
                return _instructions;

            }

            [HarmonyPatch(typeof(HandSlot), nameof(HandSlot.MaybeWeapon), MethodType.Getter)]
            [HarmonyTranspiler]
            public static IEnumerable<CodeInstruction> Transpiler4(IEnumerable<CodeInstruction> instructions)
            {
                Main.Comment.Log("Entered HandSlot MaybeWeapon getter transpiler");
                List<CodeInstruction> _instructions = instructions.ToList();

                CodeInstruction[] toSearch =
                    new CodeInstruction[]
                    {
                        new CodeInstruction(OpCodes.Ldfld, typeof(UnitDescriptor).GetField(nameof(UnitDescriptor.State))),
                        new CodeInstruction(OpCodes.Ldfld, typeof(UnitState).GetField(nameof(UnitState.Features))),
                        new CodeInstruction(OpCodes.Ldfld, typeof(UnitMechanicFeatures).GetField(nameof(UnitMechanicFeatures.ShieldBash))),
                        new CodeInstruction(OpCodes.Call),
                        new CodeInstruction(OpCodes.Brtrue_S)
                    };

                int index = Utilities.IndexFinder(instructions, toSearch);
                if (index == -1) { Main.Comment.Log("Failed to find index of HandSlot.Owner.UnitDescriptor.State.Features.ShieldBash"); return instructions; };

                _instructions.InsertRange(index,
                    new CodeInstruction[]
                    {
                        new CodeInstruction (OpCodes.Ldsfld, typeof(OffHandParryUnitPart).GetField(nameof(OffHandParryUnitPart.flag))),
                        new CodeInstruction(_instructions[index -1]),
                    });

                foreach (CodeInstruction i in _instructions) Main.Comment.Log(i.ToString());
                return _instructions;

            }


            [HarmonyPatch(typeof(CharSheetWeapons), nameof(CharSheetWeapons.Initialize))]
            [HarmonyTranspiler]
            public static IEnumerable<CodeInstruction> Transpiler3(IEnumerable<CodeInstruction> instructions)
            {
                Main.Comment.Log("Entered RuleCalculateAttacksCount OnTrigger transpiler");
                List<CodeInstruction> _instructions = instructions.ToList();

                CodeInstruction[] toSearch =
                    new CodeInstruction[]
                    {
                        new CodeInstruction(OpCodes.Ldfld, typeof(UnitDescriptor).GetField(nameof(UnitDescriptor.State))),
                        new CodeInstruction(OpCodes.Ldfld, typeof(UnitState).GetField(nameof(UnitState.Features))),
                        new CodeInstruction(OpCodes.Ldfld, typeof(UnitMechanicFeatures).GetField(nameof(UnitMechanicFeatures.ShieldBash))),
                        new CodeInstruction(OpCodes.Call),
                        new CodeInstruction(OpCodes.Brtrue_S)
                    };

                int index = Utilities.IndexFinder(instructions, toSearch);
                if (index == -1) { Main.Comment.Log("Failed to find index of Initiator.State.Features.ShieldBash"); return instructions; };

                _instructions.InsertRange(index - 1,
                    new CodeInstruction[]
                    {
                        new CodeInstruction (OpCodes.Ldarg_1),
                        CodeInstruction.Call(typeof(OffHandParry), nameof(OffHandParry.BucklerOrBash3))
                    });

                foreach (CodeInstruction i in _instructions) Main.Comment.Log(i.ToString());
                return _instructions;

            }


        }

        [HarmonyPatch(typeof(TwoWeaponFightingAttackPenalty), nameof(TwoWeaponFightingAttackPenalty.OnEventAboutToTrigger))]
        public static class TwoWeaponFightingAttackPenalty_patch_OffHandParry
        {
            [HarmonyTranspiler]
            public static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
            {
                Main.Comment.Log("");
                Main.Comment.Log("Entered TwoWeaponFightingAttackPenalty OnEventAboutToTrigger transpiler for OffHand parry");

                List<CodeInstruction> _instructions = instructions.ToList();

                CodeInstruction[] toSearch1 = new CodeInstruction[]
                {
                    new CodeInstruction(OpCodes.Stloc_1)
                };
                CodeInstruction[] toSearch2 = new CodeInstruction[]
                {
                    new CodeInstruction(OpCodes.Stloc_2)
                };

                int index1 = Utilities.IndexFinder(_instructions, toSearch1);
                int index2 = Utilities.IndexFinder(_instructions, toSearch2);
                int index = index1 > index2 ? index1 : index2;

                CodeInstruction[] toInsert = new CodeInstruction[]
                {
                    new CodeInstruction(OpCodes.Ldarg_1),
                    new CodeInstruction(OpCodes.Ldloca, 1),
                    new CodeInstruction(OpCodes.Ldloca, 2),
                    CodeInstruction.Call(typeof(TwoWeaponFightingAttackPenalty_patch_OffHandParry), nameof(OffHandParryCheck))
                };
                _instructions.InsertRange(index, toInsert);
                foreach (CodeInstruction instruction in _instructions) Main.Comment.Log(instruction.ToString());
                return _instructions;
            }

            public static void OffHandParryCheck(RuleCalculateAttackBonusWithoutTarget evt, ref ItemEntityWeapon weapon2, ref bool flag)
            {
                OffHandParryUnitPart part = evt.Initiator.Get<OffHandParryUnitPart>();
                if (part is not null && part.activated)
                {
                    weapon2 = part.weapon;
                    flag = false;
                };

                MechanicsFeatureExtension.MechanicsFeatureExtensionPart part2 = evt.Initiator.Get<MechanicsFeatureExtension.MechanicsFeatureExtensionPart>();
                if (part2 is not null && part2.ForceDualWieldingPenalties) flag = false;
            }

        }


        public static bool BucklerOrBash(bool flag, RuleCalculateAttacksCount evt)
        {
            if (flag is false) return flag;
            return flag && (evt.Initiator.Body.SecondaryHand.Shield.Blueprint.Type.ProficiencyGroup != ArmorProficiencyGroup.Buckler || evt.Initiator.Get<MechanicsFeatureExtension.MechanicsFeatureExtensionPart>()?.BucklerBash);
        }
        public static bool BucklerOrBash2(bool flag, HandSlot slot)
        {
            if (flag is true) return flag;
            OffHandParryUnitPart part = slot.Owner.Get<OffHandParryUnitPart>();
            if (part is null || !OffHandParryUnitPart.flag) return false;
            //Main.Comment.Log("Went through checks for BucklerOrBash2");
            return true;
        }
        public static bool BucklerOrBash3(bool flag, UnitEntityData unit)
        {
            if (flag is false) return flag;
            return flag && (unit.Body.SecondaryHand.Shield.Blueprint.Type.ProficiencyGroup != ArmorProficiencyGroup.Buckler || unit.Get<MechanicsFeatureExtension.MechanicsFeatureExtensionPart>()?.BucklerBash);
        }


        [HarmonyPatch(typeof(ItemEntityShield))]
        public static class ItemEntityShield_patch_WeaponComponentForBucklers
        {
            [HarmonyPatch(MethodType.Constructor, new Type[] { typeof(BlueprintItemShield) })]
            [HarmonyPostfix]
            public static void Postfix_Constructor(ItemEntityShield __instance, BlueprintItemShield bpItem)
            {
                //Main.Comment.Log("Entered Shield Constructor postfix");
                if (__instance.WeaponComponent == null && bpItem.Type.ProficiencyGroup == ArmorProficiencyGroup.Buckler)

                    __instance.WeaponComponent = new ItemEntityWeapon(LightShieldWeapon, __instance);

                //Main.Comment.Log("Weapon component for the shield " + __instance.Name + " is " + __instance.WeaponComponent);
            }

            [HarmonyPatch(nameof(ItemEntityShield.OnTurnOn))]
            [HarmonyPrefix]
            public static void Prefix_OnTurnOn(ItemEntityShield __instance)
            {
                //Main.Comment.Log("Entered Shield OnTurnOn Prefix");
                if (__instance.WeaponComponent == null && __instance.Blueprint.Type.ProficiencyGroup == ArmorProficiencyGroup.Buckler)

                    __instance.WeaponComponent = new ItemEntityWeapon(LightShieldWeapon, __instance);

                //Main.Comment.Log("Weapon component for the shield " + __instance.Name + " is " + __instance.WeaponComponent.Name);
            }
        }


    }
}
