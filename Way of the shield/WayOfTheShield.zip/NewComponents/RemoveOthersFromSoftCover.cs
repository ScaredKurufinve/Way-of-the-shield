﻿using System;
using System.Collections.Generic;
using Kingmaker.Blueprints.Root.Strings;
using Kingmaker.UI.Common;
using Kingmaker.UnitLogic;
using static Way_of_the_shield.Main;
using static Way_of_the_shield.Utilities;

namespace Way_of_the_shield.NewComponents
{
    public class RemoveOthersFromSoftCover : UnitFactComponentDelegate, IInitiatorRulebookHandler<SoftCover.RuleSoftCover>
    {
        public void OnEventAboutToTrigger(SoftCover.RuleSoftCover evt) { }
        public void OnEventDidTrigger(SoftCover.RuleSoftCover evt)
        {
            UnitEntityData owner = Owner;
            //if (Settings.IsEnabled("Debug"))
            Comment.Log("Entered RemoveOthersFromSoftCover component OnEventDidTrigger. Owner is {0}, event weapon is {1}.", new object[] { owner.CharacterName, evt.Weapon.Blueprint.m_DisplayNameText });

            if (CheckWeaponType == 0) goto checkFacts;
            else if (CheckWeaponType == WeaponTypesForSoftCoverDenial.Reach && !(UIUtilityItem.GetRange(evt.Weapon) == UIStrings.Instance.Tooltips.ReachWeapon)) return;
            else if (CheckWeaponType == WeaponTypesForSoftCoverDenial.Ranged && !evt.Weapon.Blueprint.IsRanged) return;
            bool flag1;

        checkFacts:
            HashSet<(UnitEntityData unit, int, int)> s = new();
            foreach ((UnitEntityData unit, int, int) obstacle in evt.Result)
            {
                UnitEntityData unit = obstacle.unit;
                //if (Settings.IsEnabled("Debug"))
                Comment.Log("Checking unit {0}. Is ally? {1} ", new object[] { unit.CharacterName, unit.IsAlly(Owner) });
                if (!(OnlyAlly && unit.IsAlly(Owner))) continue;
                flag1 = true;
                if (CheckFacts)
                {
                    foreach (BlueprintUnitFactReference reference in FactsToCheck)
                    {
                        if (!unit.HasFact(reference.Get()))
                        {
                            flag1 = false;
                            break;
                        }
                    }
                }
                if (flag1)
                {
                    s.Add(obstacle);
                    //if (Settings.IsEnabled("Debug"))
                    Comment.Log("Removed {0} is prepared to be removed from the obstacles set.", new object[] { obstacle.unit.CharacterName });
                }
            }
            evt.Result.RemoveRange(s);
        }

        public WeaponTypesForSoftCoverDenial CheckWeaponType = 0;
        public bool OnlyAlly;
        public bool CheckFacts;
        public BlueprintUnitFactReference[] FactsToCheck = Array.Empty<BlueprintUnitFactReference>();
    }
}
