﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kingmaker.UnitLogic.Mechanics.Actions;
using Kingmaker.Blueprints;
using Kingmaker.Blueprints.Items.Ecnchantments;
using Kingmaker.Blueprints.JsonSystem;
using Kingmaker.ElementsSystem;
using Kingmaker.EntitySystem.Entities;
using Kingmaker.Items.Slots;
using Kingmaker.UI.GenericSlot;
using Kingmaker.Utility;
using UnityEngine;
using UnityEngine.Serialization;
using Kingmaker.Items;
using Kingmaker.UnitLogic.FactLogic;
using Kingmaker.UnitLogic.Parts;
using static Way_of_the_shield.Main;
using Kingmaker.UnitLogic.Mechanics;
using Kingmaker;

namespace Way_of_the_shield.NewComponents
{
    public class ContextActionEnchantShield : ContextActionEnchantWornItem
    {
        public override void RunAction()
        {
            MechanicsContext.Data data = ContextData<MechanicsContext.Data>.Current;
            MechanicsContext mechanicsContext = (data != null) ? data.Context : null;
            if (mechanicsContext == null)
            {
                PFLog.Mods.Error(this, "Unable to apply buff: no context found");
                return;
            }
            Rounds value = DurationValue.Calculate(mechanicsContext);
            UnitEntityData unitEntityData = ToCaster ? mechanicsContext.MaybeCaster : Target.Unit;
            if (unitEntityData == null)
            {
                PFLog.Mods.Error(this, "Can't apply buff: target is null");
                return;
            };            
            ItemEntity shield;
            HandSlot slot = unitEntityData.Body.SecondaryHand;
            shield = slot?.MaybeShield;
            if (shield is not null) goto doEnchant;
            shield = slot?.MaybeWeapon;
            if (shield is not null
                && shield is ItemEntityWeapon weapon
                && weapon.Blueprint.Category is WeaponCategory.SpikedHeavyShield or WeaponCategory.SpikedLightShield)
                goto doEnchant;
            slot = unitEntityData.Body.PrimaryHand;
            weapon = slot.MaybeWeapon;
            if (!(weapon.Blueprint.Category is WeaponCategory.SpikedHeavyShield or WeaponCategory.SpikedLightShield)) return;

            doEnchant:
            ItemEnchantment fact = shield.Enchantments.GetFact(this.Enchantment);
            if (fact != null)
            {
                if (!fact.IsTemporary)
                {
                    return;
                }
                shield.RemoveEnchantment(fact);
            }
            shield.AddEnchantment(Enchantment, mechanicsContext, new Rounds?(value)).RemoveOnUnequipItem = RemoveOnUnequip;
        }
    }
}
