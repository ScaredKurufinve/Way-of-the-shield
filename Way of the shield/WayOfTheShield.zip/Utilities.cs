﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using Kingmaker.Blueprints.Classes;
using Kingmaker.Blueprints.Classes.Selection;
using Kingmaker.Blueprints.Root;
using Kingmaker.Blueprints.Root.Strings;
using Kingmaker.Designers.EventConditionActionSystem.Actions;
using Kingmaker.Designers.Mechanics.Facts;
using Kingmaker.ElementsSystem;
using Kingmaker.RuleSystem.Rules;
using Kingmaker.UI;
using Kingmaker.UI.Common;
using Kingmaker.UnitLogic;
using Kingmaker.UnitLogic.Abilities.Components.AreaEffects;
using Kingmaker.UnitLogic.Abilities.Blueprints;
using Kingmaker.UnitLogic.Abilities.Components;
using Kingmaker.UnitLogic.ActivatableAbilities;
using Kingmaker.UnitLogic.Buffs.Blueprints;
using Kingmaker.UnitLogic.Buffs.Components;
using Kingmaker.UnitLogic.FactLogic;
using Kingmaker.UnitLogic.Mechanics;
using Kingmaker.UnitLogic.Mechanics.Actions;
using Kingmaker.UnitLogic.Mechanics.Components;
using Kingmaker.UnitLogic.Mechanics.Conditions;
using static Way_of_the_shield.Main;
using System.IO;
using UnityEngine;

namespace Way_of_the_shield
{
    [HarmonyPatch]
    public static class Utilities
    {

        [HarmonyPatch(typeof(BonusSourceStrings), nameof(BonusSourceStrings.GetText))]
        public static class BonusTypeExtenstions
        {
            static readonly (BonusType, LocalizedString, int)[] entries_start = new (BonusType, LocalizedString, int)[]
            {
               (BonusType.None, new() { Key = "BonusType_NonProficient_name" }, 160),
               (BonusType.None, new() { Key = "BonusType_Backstab_name" }, 161)
            };

            public static Dictionary<int, (BonusType type, LocalizedString name)> entries = new();



            static BonusTypeExtenstions()
            {
                foreach ((BonusType type, LocalizedString name, int number) in entries_start)
                {

                    entries.Add(
                        key: number,
                        value: ((BonusType)Enum.ToObject(typeof(BonusType), number), name));


                    if (Settings.IsEnabled("Debug"))
                        Comment.Log("converted Localized String " + type + " into a BonustType = " + number);

                }
            }


            public static BonusType GetBonusType(int n)
            {
                if (entries.TryGetValue(n, out (BonusType type, LocalizedString name) found)) return found.type;

                Comment.Error("Requsted a BonusType by number " + n + " and it wasn't found");
                return BonusType.None;
            }

            [HarmonyPrefix]
            public static bool Prefix(BonusType bonusType, ref string __result)
            {

                if ((int)bonusType < 160) return true;
                foreach ((BonusType type, LocalizedString name) in entries.Values)
                {
                    if (bonusType == type)
                    {
                        __result = name;
                        return false;
                    }
                }
                return true;
            }

            public static readonly Type unitFactType = typeof(MainUnitFact);

            [HarmonyPatch(typeof(StatModifiersBreakdown), nameof(StatModifiersBreakdown.GetBonusSourceText), new Type[] { typeof(IUIDataProvider), typeof(bool) })]
            [HarmonyPrefix]
            public static bool ResolveCharName_StatModifiersBreakdown_GetBonusSourceText_Prefix(IUIDataProvider source, ref string __result)
            {

                if (source is not null && source.GetType() == unitFactType)
                {
                    string name = (source as UnitFact)?.Owner?.CharacterName;
                    if (!String.IsNullOrEmpty(name))
                    {
                        __result = name;
                        return false;
                    }
                }
                return true;
            }
        }

        [HarmonyPatch]
        public static class ModifierDescriptorExtension
        {

            const int startIndex = 90;
            static ModifierDescriptorExtension()
            {
                original = EnumUtils.GetValues<ModifierDescriptor>().ToArray();
                dummies = new ModifierDescriptor[startIndex];
                for (int i = 0; i < original.Length - 1; i++) dummies[i] = original[i];
                for (int i = original.Length - 1; i < startIndex; i++) dummies[i] = ModifierDescriptor.None;
                newDescriptors = new ModifierDescriptor[]
                {
                    SoftCover
                };
                remade = new();
                remade = dummies.ToList();
                remade.AddRange(newDescriptors);
                amount = remade.Count - 1 - EnumUtils.GetMaxValue<ModifierDescriptor>();
                if (Settings.IsEnabled("Debug"))
                    for (int i = 0; i < remade.Count() - 1; i++) Comment.Log(i + ": " + remade[i].ToString());
            }


            public const ModifierDescriptor SoftCover = (ModifierDescriptor)(startIndex + 0);

            static ModifierDescriptor[] original;
            static ModifierDescriptor[] dummies;
            public static ModifierDescriptor[] newDescriptors;

            public static List<ModifierDescriptor> remade;

            public static int amount;
            public static AbilityModifierEntry[] names = new AbilityModifierEntry[]
            {
                new () {Key = SoftCover, Name = new LocalizedString() {Key = "ModifierDescriptor_SoftCover" }}
            };


            [HarmonyPatch(typeof(ModifierDescriptorComparer), MethodType.Constructor)]
            [HarmonyTranspiler]
            public static IEnumerable<CodeInstruction> InsertNewModifierDescriptor(IEnumerable<CodeInstruction> instructions)
            {
                Comment.Log("Entered the ModifierDescriptorComparer constructor transpiler to insert new descriptors.");
                List<CodeInstruction> _instructions = instructions.ToList();

                CodeInstruction[] toSearch1 = new CodeInstruction[]
                {
                    new CodeInstruction( OpCodes.Call, typeof(EnumUtils).GetMethod(nameof(EnumUtils.GetMaxValue)).MakeGenericMethod(typeof(ModifierDescriptor)) )
                };

                int index1 = IndexFinder(_instructions, toSearch1);
                if (index1 == -1)
                {
                    Comment.Log("Failed to find the GetMaxValue<ModifierDescriptor>()");
                    return instructions;
                }
                CodeInstruction[] toInsert1 = new CodeInstruction[]
                {
                    new CodeInstruction(OpCodes.Ldsfld, typeof(ModifierDescriptorExtension).GetField(nameof(amount))),
                    new CodeInstruction(OpCodes.Add)
                };

                _instructions.InsertRange(index1, toInsert1);

                CodeInstruction[] toSearch2 = new CodeInstruction[]
                {
                    new CodeInstruction(OpCodes.Stloc_0)
                };

                int index2 = IndexFinder(_instructions, toSearch2, true);
                if (index2 == -1)
                {
                    Comment.Log("Failed to find the Stloc_0");
                    return instructions;
                }

                CodeInstruction[] toInsert2 = new CodeInstruction[]
                {
                    CodeInstruction.Call(typeof(ModifierDescriptorExtension), nameof(AddDescriptors1))
                };

                _instructions.InsertRange(index2, toInsert2);

                CodeInstruction[] toSearch3 = new CodeInstruction[]
                {
                    new CodeInstruction(OpCodes.Stloc_3)
                };
                int index3 = IndexFinder(_instructions, toSearch3);
                if (index3 == -1)
                {
                    Comment.Log("Failed to find the EnumUtils.GetValues<ModifierDescriptor>()");
                    return instructions;
                }
                CodeInstruction[] toInsert3 = new CodeInstruction[]
                {
                    CodeInstruction.Call(typeof(ModifierDescriptorExtension), nameof(AddDescriptors2))
                };

                _instructions.InsertRange(index3 - 2, toInsert3);

                //if (Settings.IsEnabled("Debug"))
                foreach (CodeInstruction instruction in _instructions) Comment.Log(instruction.ToString());
                return _instructions;
            }

            [HarmonyPatch(typeof(ModifierDescriptorComparer), MethodType.Constructor)]
            [HarmonyPostfix]
            public static void ApplyTTTCoreToModifierDescriptorComparer()
            {
                Comment.Log("Entered the ApplyTTTCoreToModifierDescriptorComparer");
                if (TTTCore is not null) TTTCorePatchesForSortedDescriptors()?.Invoke(null, null);
            }

            [HarmonyPatch(typeof(BlueprintsCache), nameof(BlueprintsCache.Init))]
            [HarmonyPostfix]
            public static void NewDescriptorNames()
            {
                if (Settings.IsEnabled("Debug"))
                    Comment.Log("Entered the BlueprintCache Init patch NewDescriptorNames");
                LocalizedTexts.Instance.AbilityModifiers.Entries = LocalizedTexts.Instance.AbilityModifiers.Entries.AddRangeToArray(names);

                if (Settings.IsEnabled("Debug"))
                    foreach (ModifierDescriptor descriptor in ModifierDescriptorComparer.SortedValues) Comment.Log(LocalizedTexts.Instance.AbilityModifiers.GetName(descriptor));
            }

            static List<ModifierDescriptor> AddDescriptors1(List<ModifierDescriptor> original)
            {
                Comment.Log("I'm inside AddDescriptors1.");
                return remade;
            }
            static IEnumerable<ModifierDescriptor> AddDescriptors2(IEnumerable<ModifierDescriptor> original)
            {
                Comment.Log("I'm inside AddDescriptors2");
                return remade;
            }

            static MethodInfo TTTCorePatchesForSortedDescriptors()
            {
                Type t = TTTCore.GetTypes().Where(type => type.FullName.Contains("AdditionalModifierDescriptors")).FirstOrDefault();
                MethodInfo returnValue = t?.GetMethods(BindingFlags.Static | BindingFlags.NonPublic)?.Where(method => method.Name == "Update_ModifierDescriptorComparer_SortedValues")?.FirstOrDefault();
                if (returnValue is null) Comment.Log("Did not find the Update_ModifierDescriptorComparer_SortedValues method");
                else Comment.Log("found the Update_ModifierDescriptorComparer_SortedValues method");
                return returnValue;
            }
        }
        public static class EnchantPoolExtensions
        {
            public const EnchantPoolType DivineShield = (EnchantPoolType)20;
        }

        public static int IndexFinder(IEnumerable<CodeInstruction> original, CodeInstruction[] RangeToSearch, bool before = false)
        {
            if (RangeToSearch.Count() >= original.Count()) { Main.Comment.Log("IndexFinder was given a range to search longer than the original"); return -1; };

            Main.Comment.Log("");
            Main.Comment.Log("Searching for instructions:");
            foreach (CodeInstruction i in RangeToSearch) Main.Comment.Log(i.ToString());
            Main.Comment.Log("");


            int length = RangeToSearch.Count();
            CodeInstruction[] orArray = original.ToArray();
            int index = -1;
            bool found;
            int limit = original.Count() - length + 1;
            for (int i = 0; i < limit; i++)
            {
                found = true;
                for (int b = 0; b < length; b++)
                {
                    if (!(orArray[i + b].Is(RangeToSearch[b])))
                    {
                        found = false;
                        break;
                    }
                }
                if (found)
                {
                    index = before ? i : i + length;
                    break;
                }
            }

            if (index == -1) Main.Comment.Log("Found nothing");
            else Main.Comment.Log("Index = " + index);

            return index;

        }

        public static bool Is(this CodeInstruction original, CodeInstruction toCompare)
        {
            OpCode? cmpCode = toCompare.opcode;
            object cmpOperand = toCompare.operand;
            if (cmpCode is null && cmpOperand is null) return true;
            if (cmpOperand is null) return original.opcode == toCompare.opcode;
            if (cmpCode is null) return original.OperandIs(toCompare.opcode);
            return (original.opcode == toCompare.opcode) && (original.OperandIs(cmpOperand));
        }

        public static void AddComponent(this BlueprintScriptableObject blueprint, BlueprintComponent component)
        {            
            HashSet<string> names = blueprint.ComponentsArray.Select(x => x.name).ToHashSet();
            string name_prototype = "";

            if (!String.IsNullOrEmpty(component.name))
            {
                if (!names.Contains(component.name))
                {
                    goto Name;
                };
                name_prototype = component.name;
                goto Iterate;
            };

            string bp_name = blueprint.name;
            string cmp_type = component.GetType().Name;
            string mod_name = modName;
            name_prototype.Concat(mod_name);
            if (!(String.IsNullOrEmpty(bp_name))) name_prototype.Concat(bp_name);
            if (!(String.IsNullOrEmpty(cmp_type))) name_prototype.Concat(cmp_type);

            Iterate: int i = 0;
            while (names.Contains(name_prototype + i))
            {
                i++;
            }
            component.name = name_prototype + i;
        Name: component.OwnerBlueprint = blueprint;
            if (blueprint.Components is null)
                blueprint.Components = new BlueprintComponent[1] { component };
            else    blueprint.Components = blueprint.Components.Append(component).ToArray();


        }
        public static Sprite LoadIcon(string IconName, int size = 64)
        {
            if (String.IsNullOrEmpty(IconName)) return null;
            var bytes = File.ReadAllBytes(modPath + Path.DirectorySeparatorChar + "Icons" + Path.DirectorySeparatorChar + IconName + ".png");
            Texture2D texture = new(size, size, TextureFormat.RGBA32, false);
            texture.LoadImage(bytes);
            var sprite = Sprite.Create(texture, new Rect(0, 0, size, size), new Vector2(0, 0));
            return sprite;

        }

        public static bool RetrieveBlueprint<T>(string GUID, out T blueprint, string name = null, string circumstances = null) where T : BlueprintScriptableObject
        {
            blueprint = null;
            BlueprintScriptableObject bp_base;
            if (!Guid.TryParse(GUID, out Guid guid))
            {
                Comment.Error("ERROR! Failed to parse string {0} into a GUID while retrieving a blueprint requested with the name {1}{2}.", GUID, name, " " + (circumstances ?? ""));
                return false;
            }
            try
            {
                bp_base = ResourcesLibrary.TryGetBlueprint<BlueprintScriptableObject>(new BlueprintGuid(guid));
            }
            catch
            {
                Comment.Error("ERROR! Failed to retrieve blueprint {0} by GUID {1} {2}", new object[] { name, GUID, circumstances });
                return false;
            }

            if (bp_base is null)
            {
                Comment.Error("ERROR! Failed to retrieve blueprint {0} by GUID {1} {2}", new object[] { name, GUID, circumstances });
                return false;
            }
            blueprint = bp_base as T;
            if (blueprint is not null) return true;
            else
            {
                Comment.Error("ERROR! Failed to convert blueprint {0} of type {1} by GUID {2} requested with the name {3} into the type {4}{5}.", bp_base.name, bp_base.GetType(), GUID, name, typeof(T), " " + (circumstances ?? ""));
                return false;
            }
        }
        public static void AddFeatureToSelections(this BlueprintFeature feature, HashSet<(string, string)> selections)
        {
            string featureName = (!String.IsNullOrEmpty(feature.m_DisplayName) ? feature.m_DisplayName : feature.name);
            BlueprintFeatureReference featureToList = feature.ToReference<BlueprintFeatureReference>();
            if (featureToList is null)
            {
                Comment.Warning("WARNING. Failed to create reference out of {0} feature when adding to feat selection lists", new object[] { featureName });
                return;
            }
            foreach ((string GUID, string name) in selections)
            {
                if (!RetrieveBlueprint(GUID, out BlueprintFeatureSelection fs, name, "when adding the " + featureName + " feature to selections")) continue;
                fs.m_AllFeatures = fs.m_AllFeatures.AddToArray(featureToList);
                Comment.Log("Successfully added " + featureName + " to " + name);
            };
        }
        public static void AddToCache(this BlueprintScriptableObject bp) 
        {
            if (ResourcesLibrary.BlueprintsCache.m_LoadedBlueprints.Keys.Any(x => x == bp.AssetGuid))
            {
                Comment.Error("While adding blueprint {0} with guid {1}, another blueprint with the same guid has been found!", bp, bp.AssetGuid);
                return;
            }
            try
            {
                ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(bp.AssetGuid, bp);
                Comment.Log("Added blueprint {1} with the guid {0} to the cache.", bp.AssetGuid, bp);
            }
            catch 
            {
                StackTrace trace = new();
                StackFrame frame = trace.GetFrame(1);
                Comment.Error("Failed to add a blueprint to the cache! Calling method is {0}, {1}", frame.GetMethod().Name , frame.GetMethod().DeclaringType.Name); 
            }
            
        }

        public static void AddFeatureAsTeamwork(this BlueprintFeature feature,
                                                (string BuffGuid, string AreaEffectGuid, string AreaBuffGuid, string SwitchBuffGuid, string ToggleAbilityGuid) PackRagerGuids = default((string, string, string, string, string)),
                                                string CavalierGuid = null,
                                                (string BuffGuid, string AbilityGuid) VanguardGuids = default((string, string)))
        {
            string name = feature.name.Replace(modName + "_", "").Replace("Feature", "");
            Comment.Log("Begin adding {0} as a teamwork feature.", name);
            feature.AddFeatureToSelections(selections);
            BlueprintFeatureReference r = feature.ToReference<BlueprintFeatureReference>();
            BlueprintUnitFactReference r2 = feature.ToReference<BlueprintUnitFactReference>();
            AbilityApplyFact aaf;
            ShareFeaturesWithPet sfwp;
            AddFactsFromCaster affc;
            #region Teamwork feature to Pack Rager
            #region Create Pack Rager Buff
            if (String.IsNullOrEmpty(PackRagerGuids.BuffGuid)) goto skipPackRager;
            BlueprintBuff PackRagerBuff = new()
            {
                AssetGuid = new BlueprintGuid(new Guid(PackRagerGuids.BuffGuid)),
                name = "PackRager_" + name + "Buff",
                IsClassFeature = true,
                Stacking = StackingType.Replace,
                m_Icon = ResourcesLibrary.TryGetBlueprint<BlueprintActivatableAbility>("4230d0ca826cb6b4fb6db6cdb318ec8e")?.Icon,
                FxOnRemove = new(),
                Components = new BlueprintComponent[] { }
            };
            PackRagerBuff.AddComponent(new AddTemporaryFeat() { m_Feat = r });
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(PackRagerBuff.AssetGuid, PackRagerBuff);
            Comment.Log("Added {0}  to the BlueprintsCache", PackRagerBuff.name);
            #endregion
            #region Create Pack Rager area effect
            if (String.IsNullOrEmpty(PackRagerGuids.AreaEffectGuid)) goto skipPackRager;
            BlueprintAbilityAreaEffect PackRagerAreaEffect = new()
            {
                AssetGuid = new BlueprintGuid(new Guid(PackRagerGuids.AreaEffectGuid)),
                name = "PackRager_" + name + "Area",
                m_TargetType = BlueprintAbilityAreaEffect.TargetType.Ally,
                SpellResistance = false,
                AffectEnemies = false,
                AffectDead = false,
                AggroEnemies = false,
                Shape = AreaEffectShape.Cylinder,
                Size = new Feet(50),
                Fx = new(),
                CanBeUsedInTacticalCombat = false,
                m_SizeInCells = 0,
                Components = new BlueprintComponent[] { }
            };
            PackRagerAreaEffect.AddComponent(new AbilityAreaEffectRunAction()
            {
                UnitMove = new(),
                UnitExit = new()
                {
                    Actions = new GameAction[] { new ContextActionRemoveBuff() {
                                                                                        m_Buff = PackRagerBuff.ToReference<BlueprintBuffReference>()} }
                },
                UnitEnter = new()
                {
                    Actions = new GameAction[] { new ContextActionApplyBuff() {
                                                                                          m_Buff = PackRagerBuff.ToReference<BlueprintBuffReference>(),
                                                                                          Permanent = true,
                                                                                          DurationSeconds = new(),
                                                                                          IsFromSpell = false,
                                                                                          AsChild = true} }
                },
                Round = new()
            });
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(PackRagerAreaEffect.AssetGuid, PackRagerAreaEffect);
            Comment.Log("Added {0}  to the BlueprintsCache", PackRagerAreaEffect.name);
            #endregion
            #region Create Pack Rager area buff
            if (String.IsNullOrEmpty(PackRagerGuids.AreaBuffGuid)) goto skipPackRager;
            BlueprintBuff PackRagerAreaBuff = new()
            {
                AssetGuid = new BlueprintGuid(new Guid(PackRagerGuids.AreaBuffGuid)),
                name = "PackRager_" + name + "AreaBuff",
                m_Icon = feature.m_Icon,
                IsClassFeature = true,
                m_Flags = BlueprintBuff.Flags.StayOnDeath,
                Stacking = StackingType.Replace,
                FxOnRemove = new(),
            };
            PackRagerAreaBuff.AddComponent(new AddAreaEffect() { m_AreaEffect = PackRagerAreaEffect.ToReference<BlueprintAbilityAreaEffectReference>() });
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(PackRagerAreaBuff.AssetGuid, PackRagerAreaBuff);
            Comment.Log("Added {0}  to the BlueprintsCache", PackRagerAreaBuff.name);
            #endregion
            #region create Pack Rager switch buff
            if (String.IsNullOrEmpty(PackRagerGuids.SwitchBuffGuid)) goto skipPackRager;
            BlueprintBuff PackRagerSwitchBuff = new()
            {
                AssetGuid = new BlueprintGuid(new Guid(PackRagerGuids.SwitchBuffGuid)),
                name = "PackRager_" + name + "Buff",
                m_Icon = feature.m_Icon,
                m_DisplayName = new() { Key = "PackRagerAreaBuff_" + name + "_DisplayName" },
                IsClassFeature = true,
                m_Flags = BlueprintBuff.Flags.StayOnDeath,
                FxOnRemove = new(),
                Stacking = StackingType.Replace,
                ComponentsArray = new BlueprintComponent[] { }
            };
            PackRagerSwitchBuff.AddComponent(new BuffExtraEffects()
            {
                m_CheckedBuff = ResourcesLibrary.TryGetBlueprint<BlueprintBuff>("da8ce41ac3cd74742b80984ccc3c9613").ToReference<BlueprintBuffReference>(),
                m_ExtraEffectBuff = PackRagerAreaBuff.ToReference<BlueprintBuffReference>()
            });
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(PackRagerSwitchBuff.AssetGuid, PackRagerSwitchBuff);
            Comment.Log("Added {0} to the blueprint cache.", PackRagerSwitchBuff.name);
            #endregion
            #region Create Pack Rager toggle ability
            if (String.IsNullOrEmpty(PackRagerGuids.ToggleAbilityGuid)) goto skipPackRager;
            BlueprintActivatableAbility PackRagerToggleAbility = new()
            {
                AssetGuid = new BlueprintGuid(new Guid(PackRagerGuids.ToggleAbilityGuid)),
                name = "PackRager_" + name + "ToggleAbility",
                m_DisplayName = feature.m_DisplayName,
                m_Description = feature.m_Description,
                m_DescriptionShort = feature.m_DescriptionShort,
                m_Icon = PackRagerBuff.Icon,
                Group = ActivatableAbilityGroup.RagingTactician,
                WeightInGroup = 1,
                IsOnByDefault = true,
                DeactivateImmediately = true,
                ActivationType = AbilityActivationType.Immediately,
                m_Buff = PackRagerSwitchBuff.ToReference<BlueprintBuffReference>()
            };
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(PackRagerToggleAbility.AssetGuid, PackRagerToggleAbility);
            Comment.Log("Added {0}  to the BlueprintsCache", PackRagerToggleAbility.name);
            #endregion
            #region add Pack Rager toggle ability to PackRagerRagingTacticianBaseFeature
            if (PackRagerRagingTacticianBaseFeature is null) goto skipPackRager;
            PackRagerRagingTacticianBaseFeature.AddComponent(new AddFeatureIfHasFact()
            {
                m_CheckedFact = r2,
                m_Feature = PackRagerToggleAbility.ToReference<BlueprintUnitFactReference>()
            });
            Comment.Log("Added {0} to the Raging Tactician Base Feature components array.", PackRagerToggleAbility.name);
        #endregion
        #endregion
        skipPackRager:
            #region Teamwork feature to Cavalier
            #region Create Cavalier buff
            if (String.IsNullOrEmpty(CavalierGuid)) goto skipCavalier;
            BlueprintBuff CavalierBuff = new()
            {
                AssetGuid = new BlueprintGuid(new Guid(CavalierGuid)),
                name = "CavalierTactician_" + name + "Buff",
                m_DisplayName = feature.m_DisplayName,
                m_Description = feature.m_Description,
                m_DescriptionShort = feature.m_DescriptionShort,
                m_Icon = feature.m_Icon,
                IsClassFeature = true,
                Stacking = StackingType.Ignore,
                Components = new BlueprintComponent[] { },
            };
            CavalierBuff.AddComponent(new AddFeatureIfHasFact() { Not = true, m_CheckedFact = r2, m_Feature = r2 });
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(CavalierBuff.AssetGuid, CavalierBuff);
            Comment.Log("Added {0} to the Blueprints cache.", CavalierBuff.name);
            #endregion
            #region Add Cavalier buff to Cavalier ability
            if (CavalierTacticianAbility is null) goto skipCavalier;
            aaf = CavalierTacticianAbility.Components.Select(c => c as AbilityApplyFact).FirstOrDefault();
            if (aaf is null) goto skipCavalier;
            aaf.m_Facts = aaf.m_Facts.AddToArray(CavalierBuff.ToReference<BlueprintUnitFactReference>());
            Comment.Log("Added {0} to the Cavalier Tactician Ability.", CavalierBuff.name);
            #endregion
            #region Add Cavalier buff to Cavalier Swift ability
            if (CavalierTacticianAbilitySwift is null) goto skipCavalier;
            aaf = CavalierTacticianAbilitySwift.Components.Select(c => c as AbilityApplyFact).FirstOrDefault();
            if (aaf is null) goto skipCavalier;
            aaf.m_Facts = aaf.m_Facts.AddToArray(CavalierBuff.ToReference<BlueprintUnitFactReference>());
            Comment.Log("Added {0} to the Cavalier Tactician Ability.", CavalierBuff.name);
            #endregion
            #region add to CavalierTacticianSupportFeature
            if (CavalierTacticianSupportFeature is null) goto skipCavalier;
            CavalierTacticianSupportFeature.Components.AddToArray(new AddFeatureIfHasFact() { m_CheckedFact = r2, m_Feature = CavalierBuff.ToReference<BlueprintUnitFactReference>() });
            Comment.Log("Added {0} to the Cavalier Tactician Support Feature.", CavalierBuff.name);
        #endregion
        #endregion
        skipCavalier:
            #region Teamwork feature to Hunter Tactics
            sfwp = HunterTactics?.ComponentsArray.FindOrDefault(c => c is ShareFeaturesWithPet) as ShareFeaturesWithPet;
            if (sfwp is not null) sfwp.m_Features = sfwp.m_Features.AddToArray(r);
            Comment.Log("Added {0} to the Hunter Tactics.", name);
            #endregion
            #region Teamwork feature to Monster Tactics 
            affc = MonsterTacticsBuff?.ComponentsArray.FindOrDefault(c => c is AddFactsFromCaster) as AddFactsFromCaster;
            if (affc is not null) affc.m_Facts = affc.m_Facts.AddToArray(r2);
            Comment.Log("Added {0} to the Monster Tactics.", name);
            #endregion
            #region Teamwork feature to Sacred Huntsmaster
            sfwp = SacredHuntsmasterTactics?.ComponentsArray.FindOrDefault(c => c is ShareFeaturesWithPet) as ShareFeaturesWithPet;
            if (sfwp is not null) sfwp.m_Features = sfwp.m_Features.AddToArray(r);
            Comment.Log("Added {0} to theSacred Huntsmaster.", name);
            #endregion
            #region Teamwork feature to Tactical Leader
            affc = TacticalLeaderFeatShareBuff?.ComponentsArray.FindOrDefault(c => c is AddFactsFromCaster) as AddFactsFromCaster;
            if (affc is not null) affc.m_Facts = affc.m_Facts.AddToArray(r2);
            Comment.Log("Added {0} to the Tactical Leader.", name);
            #endregion
            #region Teamwork feature to Battle Prowess
            affc = BattleProwessEffectBuff?.ComponentsArray.FindOrDefault(c => c is AddFactsFromCaster) as AddFactsFromCaster;
            if (affc is not null) affc.m_Facts = affc.m_Facts.AddToArray(r2);
            Comment.Log("Added {0} to the Battle Prowess.", name);
            #endregion
            #region Teamwork feature to Vanguard Tactician
            #region Create Vanguard buff
            if (String.IsNullOrEmpty(VanguardGuids.BuffGuid)) goto skipVanguardTactician;
            BlueprintBuff VanguardBuff = new()
            {
                AssetGuid = new BlueprintGuid(new Guid(VanguardGuids.BuffGuid)),
                name = "VanguardTactician_" + name + "Buff",
                m_DisplayName = feature.m_DisplayName,
                m_Description = feature.m_Description,
                m_DescriptionShort = feature.m_DescriptionShort,
                m_Icon = feature.m_Icon,
                IsClassFeature = true,
                Stacking = StackingType.Replace,
                FxOnRemove = new(),
                Components = new BlueprintComponent[] { },
            };
            VanguardBuff.AddComponent(new AddFactsFromCaster() { m_Facts = new BlueprintUnitFactReference[] { r2 } });
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(VanguardBuff.AssetGuid, VanguardBuff);
            Comment.Log("Added {0} to the Blueprints cache.", VanguardBuff.name);
            #endregion
            #region Create Vanguard Tactician ability
            if (String.IsNullOrEmpty(VanguardGuids.AbilityGuid)) goto skipVanguardTactician;
            RetrieveBlueprint("61e818d575ef4ff49a4ecbe03106add9", out BlueprintAbilityResource vtr, "VanguardTacticianResource", "when adding " + feature.name + " to Vanguard Tactian abilities.");
            BlueprintAbility VanguardAbility = new()
            {
                AssetGuid = new BlueprintGuid(new Guid(VanguardGuids.AbilityGuid)),
                name = "VanguardTactician_" + name + "Ability",
                m_DisplayName = feature.m_DisplayName,
                m_Description = feature.m_DescriptionShort,
                m_DescriptionShort = feature.m_DescriptionShort,
                LocalizedDuration = new(),
                LocalizedSavingThrow = new(),
                m_Icon = feature.m_Icon,
                Type = AbilityType.Extraordinary,
                Range = AbilityRange.Personal,
                CanTargetSelf = true,
                EffectOnAlly = AbilityEffectOnUnit.None,
                EffectOnEnemy = AbilityEffectOnUnit.None,
                m_Parent = VanguardTacticianBaseAbility?.ToReference<BlueprintAbilityReference>(),
                Animation = Kingmaker.Visual.Animation.Kingmaker.Actions.UnitAnimationActionCastSpell.CastAnimationStyle.Omni,
                ActionType = Kingmaker.UnitLogic.Commands.Base.UnitCommand.CommandType.Standard,
                Components = new BlueprintComponent[] { }
            };
            VanguardAbility.AddComponent(new AbilityResourceLogic()
            {
                m_RequiredResource = vtr?.ToReference<BlueprintAbilityResourceReference>(),
                m_IsSpendResource = true,
                Amount = 1
            });
            VanguardAbility.AddComponent(new AbilityShowIfCasterHasFact() { m_UnitFact = r2 });
            VanguardAbility.AddComponent(new AbilityTargetsAround()
            {
                m_Radius = new(30),
                m_TargetType = TargetType.Ally,
                m_SpreadSpeed = new(0)
            });
            VanguardAbility.AddComponent(new ContextRankConfig()
            {
                m_BaseValueType = ContextRankBaseValueType.ClassLevel,
                m_Progression = ContextRankProgression.Div2,
                m_Max = 20,
                m_Class = new BlueprintCharacterClassReference[] { ResourcesLibrary.TryGetBlueprint<BlueprintCharacterClass>("c75e0971973957d4dbad24bc7957e4fb")?.ToReference<BlueprintCharacterClassReference>() }
            });
            VanguardAbility.AddComponent(new AbilityEffectRunAction()
            {
                Actions = new()
                {
                    Actions = new GameAction[]
                    {
                        new Conditional()
                        {
                            ConditionsChecker = new()
                            {
                                Operation = Operation.And,
                                Conditions = new Condition[]{ new ContextConditionHasFact(){Not = true, m_Fact = r2}}
                            },
                            IfTrue = new()
                            {
                                Actions = new GameAction[]
                                {
                                    new ContextActionApplyBuff()
                                    {
                                        m_Buff = VanguardBuff.ToReference<BlueprintBuffReference>(),
                                        AsChild = true,
                                        DurationValue = new()
                                        {
                                            Rate = DurationRate.Rounds,
                                            DiceType = DiceType.One,
                                            DiceCountValue = new() {ValueType = ContextValueType.Rank, Value = 0},
                                            BonusValue = new() {ValueType = ContextValueType.Simple, Value = 3},
                                            m_IsExtendable = true
                                        }
                                    }
                                }
                            },
                            IfFalse = new()
                        }
                    }
                }
            });
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(VanguardAbility.AssetGuid, VanguardAbility);
            Comment.Log("Added {0} to the Blueprints cache.", VanguardAbility.name);
            #endregion
            #region Add Vanguard Ability to Vanguard Tatician base ability
            if (VanguardTacticianBaseAbility is null) goto skipVanguardTactician;
            AbilityVariants av = VanguardTacticianBaseAbility.Components.FindOrDefault(c => c is AbilityVariants) as AbilityVariants;
            if (av is not null) av.m_Variants = av.m_Variants.AddToArray(VanguardAbility.ToReference<BlueprintAbilityReference>());
            Comment.Log("Added {0} to the  Vanguard Tatician base ability.", VanguardAbility.name);
        #endregion
        #endregion
        skipVanguardTactician:;
        }
        static readonly HashSet<(string, string)> selections = new()
        {
            new ("247a4068296e8be42890143f451b4b45", "BasicFeatSelection"),
            new ("41c8486641f7d6d4283ca9dae4147a9f", "FighterFeatSelection"),
            new ("c5357c05cf4f8414ebd0a33e534aec50", "CrusaderFeat1"),
            new ("50dc57d2662ccbd479b6bc8ab44edc44", "CrusaderFeat10"),
            new ("2049abc955bf6fe41a76f2cb6ba8214a", "CrusaderFeat20"),
            new ("303fd456ddb14437946e344bad9a893b", "WarpriestFeatSelection"),
            new ("dd17090d14958ef48ba601688b611970", "CavalierBonusFeatSelection"),
            new ("94ebbd6472c19fa4ea7196eaff11a740", "PackRagerTeamworkFeatureSelection"),
            new ("7bc55b5e381358c45b42153b8b2603a6", "CavalierTacticianFeatSelection"),
            new ("ef1cd58e0b7fc7f45baedb09407a1cd1", "GendarmeFeatSelection"),
            new ("cf2ca457ffb585a4995fd79441167a72", "DevilbanePriestTeamworkFeatSelection"),
            new ("79c6421dbdb028c4fa0c31b8eea95f16", "WarDomainGreaterFeatSelection"),
            new ("da03141df23f3fe45b0c7c323a8e5a0e", "EldritchKnightFeatSelection"),
            new ("01046afc774beee48abde8e35da0f4ba", "HunterTeamworkFeatSelection"),
            new ("d87e2f6a9278ac04caeb0f93eff95fcb", "TeamworkFeat"),
            new ("90f105c8e31a6224ea319e6a810e4af8", "LoremasterCombatFeatSelection"),
            new ("66befe7b24c42dd458952e3c47c93563", "MagusFeatSelection"),
            new ("8e627812dc034b9db12fa396fdc9ec75", "ArcaneRiderFeatSelection"),
            new ("c5158a6622d0b694a99efb1d0025d2c1", "CombatTrick"),
            new ("29b480a26a88f9e47a10d8c9fab84ee6", "BattleProwessSelection"),
            new ("64960cdba39692243bef11da263ab7f3", "BattleScionTeamworkFeat"),
            new ("78fffe8e5d5bc574a9fd5efbbb364a03", "StudentOfWarCombatFeatSelection"),
            new ("303fd456ddb14437946e344bad9a893b", "WarpriestFeatSelection"),
            new ("cfad18f581584ac4ba066df067956477", "LifeBondingFriendshipSelection"),
            new ("69a33d6ced23446e819667149d088898", "LifeBondingFriendshipSelection1"),
            new ("e10c4f18a6c8b4342afe6954bde0587b", "ExtraFeatMythicFeat"),
            new ("a21acdafc0169f5488a9bd3256e2e65b", "DragonLevel2FeatSelection")
        };
        #region TeamworkFeatures
        static BlueprintFeature PackRagerRagingTacticianBaseFeature;
        static BlueprintFeature CavalierTacticianSupportFeature;
        static BlueprintAbility CavalierTacticianAbility;
        static BlueprintAbility CavalierTacticianAbilitySwift;
        static BlueprintFeature HunterTactics;
        static BlueprintBuff MonsterTacticsBuff;
        static BlueprintFeature SacredHuntsmasterTactics;
        static BlueprintBuff TacticalLeaderFeatShareBuff;
        static BlueprintBuff BattleProwessEffectBuff;
        static BlueprintAbility VanguardTacticianBaseAbility;

        [HarmonyPatch(typeof(BlueprintsCache), nameof(BlueprintsCache.Init))]
        [HarmonyPriority(800)]
        [HarmonyPostfix]
        public static void BlueprintsCache_Init_PatchRetrieveAllTacticianFeatures()
        {
            string circ = "when retrieving all tactican features";
            RetrieveBlueprint("54efaa577ffe5114eb839d1bee8eda95", out PackRagerRagingTacticianBaseFeature, "PackRagerRagingTacticianBaseFeature", circ);
            RetrieveBlueprint("37c496c0c2f04544b83a8d013409fd47", out CavalierTacticianSupportFeature, "CavalierTacticianSupportFeature", circ);
            RetrieveBlueprint("3ff8ef7ba7b5be0429cf32cd4ddf637c", out CavalierTacticianAbility, "CavalierTacticianAbility", circ);
            RetrieveBlueprint("78b8d3fd0999f964f82d1c5ec30900e8", out CavalierTacticianAbilitySwift, "CavalierTacticianAbility", circ);
            RetrieveBlueprint("1b9916f7675d6ef4fb427081250d49de", out HunterTactics, "HunterTactics", circ);
            RetrieveBlueprint("e1f437048db80164792155102375b62c", out SacredHuntsmasterTactics, "SacredHuntsmasterTactics", circ);
            RetrieveBlueprint("81ddc40b935042844a0b5fb052eeca73", out MonsterTacticsBuff, "MonsterTacticsBuff", circ);
            RetrieveBlueprint("a603a90d24a636c41910b3868f434447", out TacticalLeaderFeatShareBuff, "TacticalLeaderFeatShareBuff", circ);
            RetrieveBlueprint("8c8cb2f8d83035e45843a88655da8321", out BattleProwessEffectBuff, "BattleProwessEffectBuff", circ);
            RetrieveBlueprint("00af3b5f43aa7ae4c87bcfe4e129f6e8", out VanguardTacticianBaseAbility, "VanguardTacticianBaseAbility", circ);
        }
        #endregion

        public enum WeaponTypesForSoftCoverDenial
        {
            Any = 0,
            Reach = 1,
            Ranged = 2
        }
    }
}
