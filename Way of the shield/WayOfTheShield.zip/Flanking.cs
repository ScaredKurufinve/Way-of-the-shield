﻿using Kingmaker;
using Kingmaker.Armies.TacticalCombat;
using Kingmaker.Blueprints.Classes;
using Kingmaker.Blueprints.Facts;
using Kingmaker.Blueprints.Root.Strings.GameLog;
using Kingmaker.Controllers.Combat;
using Kingmaker.Designers.Mechanics.Facts;
using Kingmaker.RuleSystem.Rules;
using Kingmaker.UnitLogic;
using TurnBased.Controllers;
using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Text;
using static Way_of_the_shield.Main;

namespace Way_of_the_shield

{
    public static class Flanking
    {

        const float MinimalFlankingAngle = 110;
        const float AngleOffsetByImprovedOutflank = 50;
        static readonly RulebookEvent.CustomDataKey FlankedKey = new("Flanking");
        static readonly RulebookEvent.CustomDataKey FlankingUnitsKey = new("FlankingUnits");
        static readonly RulebookEvent.CustomDataKey Outflank = new("Outflank");
        public static BlueprintFeature ImprovedOutflank = null;
        static float GetMinimalFlankingAngle(bool AmazingOutflankers)
        {
            if (AmazingOutflankers)
                return (MinimalFlankingAngle - AngleOffsetByImprovedOutflank);
            else return MinimalFlankingAngle;
        }
        static bool AmazingOuflankers(UnitEntityData attacker, UnitEntityData flanker)
        {
            return (attacker.Progression.Features.HasFact(ImprovedOutflank) && flanker.Progression.Features.HasFact(ImprovedOutflank));
        }

        [HarmonyPatch]
        public static class UnitCombatState_IsFlanked_Patch
        {


            [HarmonyTargetMethod]
            public static MethodBase TargetMethod()
            {
                return typeof(UnitCombatState).GetProperty(nameof(UnitCombatState.IsFlanked)).GetMethod;
            }


            [HarmonyPrepare]
            public static bool Prepare()
            {
                return Settings.IsEnabled("ForbidCloseFlanking");
            }

            [HarmonyPostfix]
            public static bool Prefix(UnitCombatState __instance, ref bool __result)
            {
                if (Settings.IsEnabled("Debug")) Comment.Log("Entered the flanking prefix");
                if (Settings.IsEnabled("AllowCloseFlankingToEnemies") && __instance.Unit.IsPlayerFaction)
                {
                    if (Settings.IsEnabled("Debug"))
                        Comment.Log("Unit {0} is not player faction, prefix is skipped", new object[] { __instance.Unit.CharacterName });
                    return true;
                };
                if (__instance.Unit.Descriptor.State.Features.CannotBeFlanked) { __result = false; return false; }
                if (TacticalCombatHelper.IsActive) { __result = __instance.Unit.IsInCombat && __instance.EngagedBy.Count > 1; return false; }

                Vector3 position = __instance.Unit.Position;
                UnitEntityData[] engaged_by = CombatController.IsInTurnBasedCombat() ? __instance.EngagedBy.ToArray() : __instance.EngagedBy.Where(x => x.Commands.AnyCommandTargets(__instance.Unit)).ToArray();
                //if (Settings.IsEnabled("Debug")) 
                Comment.Log("{0} is engaged by {1} people.", new object[] { __instance.Unit.CharacterName, engaged_by.Length.ToString() });
                int i = 0;
                while (i < engaged_by.Count() - 1)
                {

                    for (int further = i + 1; further < engaged_by.Count(); further++)
                    {
                        float angle = Vector3.Angle(engaged_by[i].Position - position,
                                          engaged_by[further].Position - position);

                        //if (Settings.IsEnabled("Debug"))
                        Comment.Log("When attacking {0}, the angle between {1} and {2} is {3} degrees. Required angle is {4}.",
                            new object[] { __instance.Unit.CharacterName, engaged_by[i].CharacterName, engaged_by[further].CharacterName, angle.ToString(), GetMinimalFlankingAngle(AmazingOuflankers(engaged_by[i], engaged_by[further])) });
                        if (angle > GetMinimalFlankingAngle(AmazingOuflankers(engaged_by[i], engaged_by[further])))
                        {
                            //if (Settings.IsEnabled("Debug")) 
                            Comment.Log("Is Flanked");
                            __result = true; return false;
                        }

                    }
                    i++;
                };
                if (Settings.IsEnabled("Debug")) Comment.Log("Not Flanked");
                __result = false;
                return false;
            }
        }

        [HarmonyPatch]
        public static class RuleAttackRoll_TargetIsFlanked_Patch
        {

            [HarmonyTargetMethods]
            public static IEnumerable<MethodBase> TargetMethods()
            {
                return typeof(RuleAttackRoll).GetConstructors();
            }

            [HarmonyPostfix]
            public static void Postfix(RuleAttackRoll __instance)
            {
                if (Settings.IsEnabled("Debug"))
                    Comment.Log("Entered the RuleAttackRoll constructor postfix");
                if (__instance.IsFake) return;
                UnitEntityData target = __instance.Target;
                if (Settings.IsDisabled("ForbidCloseFlanking")
                    || (Settings.IsEnabled("AllowCloseFlankingToEnemies") && target.IsPlayerFaction))
                { __instance.TargetIsFlanked = target.CombatState.IsFlanked; return; };
                if (target.State.Features.CannotBeFlanked) { __instance.TargetIsFlanked = false; return; };
                if (TacticalCombatHelper.IsActive) { __instance.TargetIsFlanked = target.IsInCombat && target.CombatState.EngagedBy.Count > 1; return; };
                List<UnitEntityData> EngagedUnits = CombatController.IsInTurnBasedCombat() ? target.CombatState.EngagedBy.ToList() : target.CombatState.EngagedBy.Where(x => x.Commands.AnyCommandTargets(target)).ToList();
                UnitEntityData attacker = __instance.Initiator;
                if (!EngagedUnits.Contains(attacker) || EngagedUnits.Count < 2) { __instance.TargetIsFlanked = false; return; };
                EngagedUnits.Remove(attacker);
                UnitEntityData flanker = attacker; //dumb initialization to make compiler happy
                List<(UnitEntityData, float, bool)> flankers = new();
                float biggestAngle = 0;
                Vector3 targetPosition = target.Position;
                Vector3 AttackVector = attacker.Position;
                bool AREamazingOutflankers = false;
                float angle;
                bool amazingOutflankers;
                foreach (UnitEntityData possibleFlanker in EngagedUnits)
                {
                    angle = Vector3.Angle(targetPosition - AttackVector, targetPosition - possibleFlanker.Position);
                    amazingOutflankers = AmazingOuflankers(attacker, possibleFlanker);
                    flankers.Add((possibleFlanker, angle, amazingOutflankers));
                    if ((amazingOutflankers ? angle + AngleOffsetByImprovedOutflank : angle) > (AREamazingOutflankers ? biggestAngle + AngleOffsetByImprovedOutflank : biggestAngle))
                    { biggestAngle = angle; flanker = possibleFlanker; AREamazingOutflankers = amazingOutflankers; }
                }
                if (biggestAngle >= GetMinimalFlankingAngle(AREamazingOutflankers)) __instance.TargetIsFlanked = true;
                else __instance.TargetIsFlanked = false;
                if (Settings.IsEnabled("Debug"))
                    Comment.Log("When attacking {0} the angle between {1} and {2} is {3}. Improved Outflank is {5}. Flanking is {4}", new object[] { target.CharacterName, attacker.CharacterName, flanker.CharacterName, biggestAngle.ToString(), __instance.TargetIsFlanked, AREamazingOutflankers });

                __instance.SetCustomData(FlankingUnitsKey, flankers);
                __instance.SetCustomData(FlankedKey, (flanker, biggestAngle, AREamazingOutflankers));

            }
        }

        [HarmonyPatch(typeof(RuleAttackRoll), nameof(RuleAttackRoll.OnTrigger))]
        public static class RuleAttackRoll_OnTrigger_Patch
        {

            [HarmonyTranspiler]
            public static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
            {
                Comment.Log("Entered Flanking - RuleAttackRoll_OnTrigger_Patch transpiler");
                List<CodeInstruction> _instructions = instructions.ToList();

                CodeInstruction[] toSearch = new CodeInstruction[]
                {
                    new CodeInstruction (OpCodes.Ldfld, typeof(RulebookTargetEvent).GetField(nameof(RulebookTargetEvent.Target))),
                    new CodeInstruction (OpCodes.Callvirt, typeof(UnitEntityData).GetProperty(nameof(UnitEntityData.CombatState)).GetMethod),
                    new CodeInstruction (OpCodes.Callvirt, typeof(UnitCombatState).GetProperty(nameof(UnitCombatState.IsFlanked)).GetMethod)
                };

                int index = Utilities.IndexFinder(_instructions, toSearch, true);
                if (index == -1) { Comment.Log("Failed to find the index of Target.CombatState.GetMethod"); return instructions; };

                _instructions.RemoveRange(index, toSearch.Count());
                _instructions.Insert(index, CodeInstruction.Call(typeof(RuleAttackRoll), typeof(RuleAttackRoll).GetProperty(nameof(RuleAttackRoll.TargetIsFlanked)).GetMethod.Name));

                foreach (CodeInstruction inst in _instructions) { Comment.Log(inst.ToString()); };

                return _instructions;

            }
        }

        [HarmonyPatch(typeof(RuleCalculateAttackBonus), nameof(RuleCalculateAttackBonus.OnTrigger))]
        public static class RuleCalculateAttackBonus_OnTrigger_Patch
        {
            [HarmonyTranspiler]
            public static IEnumerable<CodeInstruction> Trasnpiler(IEnumerable<CodeInstruction> instructions)
            {
                Comment.Log("Entered RuleCalculateAttackBonus_OnTrigger_Patch trasnpiler");
                List<CodeInstruction> _instructions = instructions.ToList();

                CodeInstruction[] toSearch = new CodeInstruction[]
                {
                    new CodeInstruction (OpCodes.Ldfld, typeof(RulebookTargetEvent).GetField(nameof(RulebookTargetEvent.Target))),
                    new CodeInstruction (OpCodes.Callvirt, typeof(UnitEntityData).GetProperty(nameof(UnitEntityData.CombatState)).GetMethod),
                    new CodeInstruction (OpCodes.Callvirt, typeof(UnitCombatState).GetProperty(nameof(UnitCombatState.IsFlanked)).GetMethod),
                    new CodeInstruction (OpCodes.Brtrue_S),
                    new CodeInstruction (OpCodes.Ldarg_0)
                };

                int index = Utilities.IndexFinder(_instructions, toSearch, true);
                if (index == -1) { Comment.Log("Failed to find Target.CombatState.IsFlanked"); return instructions; };

                _instructions.RemoveRange(index, toSearch.Count());

                foreach (CodeInstruction instruction in _instructions) Main.Comment.Log(instruction.ToString());
                return _instructions;
            }
        }

        [HarmonyPatch]
        public static class Outflank_patches
        {

            [HarmonyPatch(typeof(OutflankAttackBonus), nameof(OutflankAttackBonus.OnEventAboutToTrigger))]
            public static class OutflankAttackBonus_OnEventAboutToTrigger_patch
            {
                [HarmonyTranspiler]
                public static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
                {
                    Comment.Log("Entered Flanking -OutflankAttackBonus_OnEventAboutToTrigger_patch transpiler");
                    List<CodeInstruction> _instructions = instructions.ToList();

                    CodeInstruction[] toSearch = new CodeInstruction[]
                    {
                    new CodeInstruction (OpCodes.Ldfld, typeof(RulebookTargetEvent).GetField(nameof(RulebookTargetEvent.Target))),
                    new CodeInstruction (OpCodes.Callvirt, typeof(UnitEntityData).GetProperty(nameof(UnitEntityData.CombatState)).GetMethod),
                    new CodeInstruction (OpCodes.Callvirt, typeof(UnitCombatState).GetProperty(nameof(UnitCombatState.IsFlanked)).GetMethod)
                    };

                    int index = Utilities.IndexFinder(_instructions, toSearch, true);
                    if (index == -1) { Comment.Log("Failed to find the index of Target.CombatState.IsFlanked"); return instructions; };

                    _instructions.RemoveRange(index, toSearch.Count());
                    _instructions.Insert(index, CodeInstruction.Call(typeof(RuleCalculateAttackBonus), typeof(RuleCalculateAttackBonus).GetProperty(nameof(RuleCalculateAttackBonus.TargetIsFlanked)).GetMethod.Name));


                    CodeInstruction[] toSearch2 = new CodeInstruction[]
                    {
                    new CodeInstruction (OpCodes.Callvirt, typeof(UnitEntityData).GetProperty(nameof(UnitEntityData.State)).GetMethod),
                    new CodeInstruction (OpCodes.Ldfld, typeof(UnitCombatState).GetField(nameof(UnitState.Features)))
                    };

                    CodeInstruction[] toSearch3 = new CodeInstruction[]
                    {
                    new CodeInstruction (OpCodes.Ldloc_0),
                    new CodeInstruction (OpCodes.Brfalse_S),
                    new CodeInstruction (OpCodes.Ldarg_1),
                    new CodeInstruction (OpCodes.Ldarg_0),
                    new CodeInstruction (OpCodes.Ldfld, typeof(OutflankAttackBonus).GetField(nameof(OutflankAttackBonus.AttackBonus)))
                    };

                    int index2 = Utilities.IndexFinder(_instructions, toSearch2, true) - 1;
                    int index3 = Utilities.IndexFinder(_instructions, toSearch3, true);
                    if (index2 == -1) { Comment.Log("Failed to find the index2 of Target.CombatState.GetMethod"); return instructions; };
                    if (index3 == -1) { Comment.Log("Failed to find the index3 of if (flag){evt.AddModifier(this.AttackBonus"); return instructions; };
                    _instructions.RemoveRange(index2, index3 - index2);

                    CodeInstruction[] ToInsert2 = new CodeInstruction[]
                    {
                        new CodeInstruction (OpCodes.Ldarg_1),
                        CodeInstruction.Call(typeof(Outflank_patches), nameof(IsSuitableForOutflank)),
                        new CodeInstruction(OpCodes.Stloc_0)
                     };

                    _instructions.InsertRange(index2, ToInsert2);

                    foreach (CodeInstruction inst in _instructions) { Comment.Log(inst.ToString()); };
                    return _instructions;


                }

                //[HarmonyPrefix]
                //public static void Prefix(RuleCalculateAttackBonus evt)
                //{
                //    Comment.Log("Entered the OutflankAttackBonus.OnEventAboutToTrigger prefix. Target is flanked? {0}. Weapon is melee? {1}", new object[] { evt.TargetIsFlanked, evt.Weapon.Blueprint.IsMelee });
                //}

                //[HarmonyPostfix]
                //public static void Postfix(OutflankAttackBonus __instance, RuleCalculateAttackBonus evt)
                //{
                //    Comment.Log("Entered the OutflankAttackBonus.OnEventAboutToTrigger postfix.");
                //    if (!evt.TargetIsFlanked || !evt.Weapon.Blueprint.IsMelee)
                //    Comment.Log("(!evt.TargetIsFlanked || !evt.Weapon.Blueprint.IsMelee) is true, exit the method.");
                //    Comment.Log("Attempt to call IsSuitable. Result is {0}", new object[] { IsSuitableForOutflank(__instance, evt)});

                //                }
            }


            [HarmonyPatch(typeof(OutflankDamageBonus), nameof(OutflankDamageBonus.OnEventAboutToTrigger))]
            public static class OutflankDamageBonus_OnEventAboutToTrigger_patch
            {
                [HarmonyTranspiler]
                public static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
                {
                    Comment.Log("OutflankDamageBonus transpiler");
                    List<CodeInstruction> _instructions = instructions.ToList();
                    CodeInstruction[] toSearch = new CodeInstruction[]
                    {
                    new CodeInstruction (OpCodes.Ldfld, typeof(RulebookTargetEvent).GetField(nameof(RulebookTargetEvent.Target))),
                    new CodeInstruction (OpCodes.Callvirt, typeof(UnitEntityData).GetProperty(nameof(UnitEntityData.CombatState)).GetMethod),
                    new CodeInstruction (OpCodes.Callvirt, typeof(UnitCombatState).GetProperty(nameof(UnitCombatState.IsFlanked)).GetMethod)
                    };

                    int index = Utilities.IndexFinder(_instructions, toSearch, true);
                    if (index == -1) { Comment.Log("Failed to find the index of Target.CombatState.IsFlanked"); return instructions; };

                    _instructions.RemoveRange(index, toSearch.Count());
                    _instructions.Insert(index, CodeInstruction.Call(typeof(RuleAttackRoll), typeof(RuleAttackRoll).GetProperty(nameof(RuleAttackRoll.TargetIsFlanked)).GetMethod.Name));

                    CodeInstruction[] toSearch2 = new CodeInstruction[]
                    {
                    new CodeInstruction (OpCodes.Callvirt, typeof(UnitEntityData).GetProperty(nameof(UnitEntityData.State)).GetMethod),
                    new CodeInstruction (OpCodes.Ldfld, typeof(UnitCombatState).GetField(nameof(UnitState.Features))),
                    new CodeInstruction (OpCodes.Ldfld, typeof(UnitMechanicFeatures).GetField(nameof(UnitMechanicFeatures.SoloTactics)))
                    };

                    CodeInstruction[] toSearch3 = new CodeInstruction[]
                    {
                    new CodeInstruction (OpCodes.Ldloc_0),
                    new CodeInstruction (OpCodes.Ldarg_0),
                    new CodeInstruction (OpCodes.Ldfld, typeof(OutflankDamageBonus).GetField(nameof(OutflankDamageBonus.IncreasedDamageBonus)))
                    };

                    int index2 = Utilities.IndexFinder(_instructions, toSearch2, true) - 1;
                    int index3 = Utilities.IndexFinder(_instructions, toSearch3, true) - 1;
                    if (index2 == -1) { Comment.Log("Failed to find the index2 of Target.CombatState.GetMethod"); return instructions; };
                    if (index3 == -1) { Comment.Log("Failed to find the index3 of Target.CombatState.GetMethod"); return instructions; };
                    _instructions.RemoveRange(index2, index3 - index2);

                    _instructions.InsertRange(index2, new CodeInstruction[]
                                                          {   new CodeInstruction (OpCodes.Ldarg_1),
                                                          CodeInstruction.Call(typeof(Outflank_patches), nameof(IsSuitableForOutflank)),
                                                          }
                    );

                    foreach (CodeInstruction inst in _instructions) { Comment.Log(inst.ToString()); };
                    return _instructions;

                }
            }

            [HarmonyPatch(typeof(OutflankProvokeAttack), nameof(OutflankProvokeAttack.OnEventDidTrigger))]
            public static class OutflankProvokeAttack_OnEventDidTrigger_patch
            {
                [HarmonyPrefix]
                public static bool Prefix(RuleAttackRoll evt, OutflankProvokeAttack __instance)
                {
                    //if (Settings.IsEnabled("Debug")) 
                    Comment.Log("Entered OutflankProvokeAttack");

                    BlueprintUnitFact outflank = __instance.OutflankFact;
                    if (evt.IsFake || !evt.IsCriticalConfirmed || (!evt.TargetIsFlanked && !evt.Weapon.Blueprint.IsMelee))
                    {
                        if (Settings.IsEnabled("Debug"))
                            Comment.Log("evt.IsFake is {0}, !evt.IsCriticalConfirmed is {1}, !evt.TargetIsFlanked is {2}, !evt.Weapon.Blueprint.IsMelee is {3}, total result is {4}", new object[] {
                                evt.IsFake, !evt.IsCriticalConfirmed, !evt.TargetIsFlanked, !evt.Weapon.Blueprint.IsMelee, (evt.IsFake || !evt.IsCriticalConfirmed || (!evt.TargetIsFlanked && !evt.Weapon.Blueprint.IsMelee)) });
                        return false;
                    }
                    if (!evt.TryGetCustomData(FlankingUnitsKey, out List<(UnitEntityData, float, bool)> flankers)) return false;

                    foreach ((UnitEntityData unit, float angle, bool amazingOutflankers) in flankers)
                    {
                        if (Settings.IsEnabled("Debug")) Comment.Log("Check for " + unit.CharacterName + ". Angle is " + angle + ". Improved Outlflank is " + amazingOutflankers);
                        if (angle > GetMinimalFlankingAngle(amazingOutflankers) && (__instance.Owner.State.Features.SoloTactics || unit.Descriptor.HasFact(outflank)))
                        {
                            //if (Settings.IsEnabled("Debug")) 
                            Comment.Log("Provoked AoO");
                            Game.Instance.CombatEngagementController.ForceAttackOfOpportunity(unit, evt.Target, false);
                        }
                    };
                    return false;
                }
            }

            public static bool IsSuitableForOutflank(UnitFactComponentDelegate outflank, RulebookEvent evt)
            {
                if (Settings.IsEnabled("Debug"))
                    Comment.Log("Entered the IsSuitableForOutflank method. Delegate is {0}, owner is {1}", new object[] { outflank.GetType(), outflank.Owner.CharacterName });
                if (outflank is not OutflankAttackBonus or OutflankDamageBonus)
                {
                    if (Settings.IsEnabled("Debug"))
                        Comment.Log("Delegate is not OutflankAttackBonus or OutflankDamageBonus. Return false.");
                    return false;
                }

                RuleAttackRoll ruleAttackRoll = Rulebook.CurrentContext.LastEvent<RuleAttackRoll>();
                if (!ruleAttackRoll.TryGetCustomData(FlankingUnitsKey, out List<(UnitEntityData, float, bool)> flankers))
                {
                    if (Settings.IsEnabled("Debug"))
                        Comment.Log("No flankers!");
                    return false;
                };

                if (ruleAttackRoll.TryGetCustomData(Outflank, out UnitEntityData previousOutflanker))
                {
                    //if (Settings.IsEnabled("Debug"))
                    Comment.Log("Outflanker has already been set by another call to the method. Outflanker is {0}", new object[] { previousOutflanker?.CharacterName });
                };

                BlueprintUnitFact fact = null;
                if (outflank is OutflankAttackBonus outflankAttackBonus) fact = outflankAttackBonus.OutflankFact;
                else if (outflank is OutflankDamageBonus outflankDamageBonus) fact = outflankDamageBonus.OutflankFact;
                if (fact is null)
                {
                    //if (Settings.IsEnabled("Debug"))
                    Comment.Warning("Fact is null!!!");
                    return false;
                }
                foreach ((UnitEntityData unit, float angle, bool amazingOutflankers) in flankers)
                {
                    if (angle > GetMinimalFlankingAngle(amazingOutflankers) && unit.HasFact(fact))
                    {
                        if (outflank is OutflankAttackBonus)
                        {
                            ruleAttackRoll.SetCustomData(Outflank, unit);
                            //if (Settings.IsEnabled("Debug"))
                            Comment.Log("Set {0} into the Outflank custom data", new object[] { unit.CharacterName });
                        };
                        return true;
                    }
                };
                if (outflank.Owner.State.Features.SoloTactics)
                {
                    if (outflank is OutflankAttackBonus)
                        ruleAttackRoll.SetCustomData(Outflank, outflank.Owner);
                    //if (Settings.IsEnabled("Debug"))
                    Comment.Log("Outflank owner has Solo Tactics. Set the owner into Outflank custom data.");
                    return true;
                }
                //if (Settings.IsEnabled("Debug"))
                Comment.Log("Return false");
                return false;
            }


            [HarmonyPatch(typeof(AttackLogMessage), nameof(AttackLogMessage.GetData))]
            public static class AttackLogMessage_GetData_patch
            {
                public static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
                {
                    Comment.Log("Entered AttackLogMessage_GetData_patch trasnpiler");
                    List<CodeInstruction> _instructions = instructions.ToList();
                    int index = Utilities.IndexFinder(_instructions, new CodeInstruction[] { new CodeInstruction(OpCodes.Call, typeof(AttackLogMessage).GetMethod(nameof(AttackLogMessage.AppendAttackBonusBreakdown))) }, true);
                    if (index == -1) { Comment.Log("Failed to find this.AppendAttackBonusBreakdown"); return instructions; };

                    CodeInstruction[] toInsert = new CodeInstruction[]
                    {
                        new CodeInstruction (OpCodes.Ldloc_2),
                        new CodeInstruction (OpCodes.Ldarg_1),
                        CodeInstruction.Call(typeof(AttackLogMessage_GetData_patch), nameof(AttackLogMessage_GetData_patch.AppendFlankingData))
                    };

                    _instructions.InsertRange(index, toInsert);
                    return _instructions;

                }


                public static void AppendFlankingData(StringBuilder sb, RuleAttackRoll rule)
                {
                    UnitEntityData target = rule.Target;
                    if (!rule.TargetIsFlanked && target.CombatState.EngagedBy.Count > 1 && target.Descriptor.State.Features.CannotBeFlanked)
                    {
                        sb.Append(target.CharacterName);
                        sb.Append(" " + m_canNotBeFkaned + "."); //Can not be flanked
                        sb.AppendLine();
                        sb.AppendLine();
                        return;
                    }
                    bool flag2 = rule.TryGetCustomData(FlankingUnitsKey, out List<(UnitEntityData, float, bool)> team);
                    bool flag3 = rule.TryGetCustomData(FlankedKey, out (UnitEntityData unit, float angle, bool amazingOutflankers) flanker);
                    if (!flag2 || !flag3) return;
                    bool presentOutflank = rule.TryGetCustomData(Outflank, out UnitEntityData outflanker);
                    bool soloTactics = presentOutflank && outflanker == rule.Initiator;
                    UnitEntityData TrueFlanker = (presentOutflank && !soloTactics) ? outflanker : flanker.unit;
                    Comment.Log("Outflank flag is {0}, True Flanker is {1}", new object[] { presentOutflank, TrueFlanker.CharacterName });
                    (UnitEntityData, float, bool) FlankerInfo = team.Find(f => f.Item1 == TrueFlanker);
                    if (rule.TargetIsFlanked)
                    {
                        sb.Append("<b>" + TrueFlanker.CharacterName + "</b> ");
                        sb.Append(m_distracts); //distracts
                        sb.Append(" " + target.CharacterName);
                        if (!soloTactics)
                        {
                            if (FlankerInfo.Item3) sb.Append(" " + m_improvedOutflank); // with an unbelievable feat of teamwork
                            else if (presentOutflank) sb.Append(" <b>" + m_masterfulFeat + "</b>"); // with a remarkable feat of teamwork                        
                        }
                        sb.Append(", " + m_while); //while
                        sb.Append(" <b>" + rule.Initiator.CharacterName + "</b> ");
                        sb.Append(m_fromAnotherFlank + " "); //attacks from another flank. Angle between them is 
                        //float angle = FlankerInfo.Item2;
                        sb.Append(FlankerInfo.Item2 + ".");
                        if (soloTactics)
                        {
                            if (rule.Initiator.State.Features.SoloTactics)
                            {
                                // sb.Append(" " + m_while + " ");
                                sb.Append(" " + outflanker.CharacterName);
                                sb.Append(m_soloTactics);
                                sb.AppendLine();
                                sb.AppendLine();
                                return;
                            }
                            else Comment.Error("When {0} was attacking {1}, True FLanker was {2}, while {2} has no Solo Tactics feature!", new object[] { rule.Initiator.CharacterName, rule.Target.CharacterName, outflanker.CharacterName });
                        }
                        sb.AppendLine();
                        sb.AppendLine();
                        return;
                    }
                    else
                    {
                        sb.Append(m_angleofAttacks); //The angle of attack between
                        sb.Append(" <b>" + rule.Initiator.CharacterName + "</b> ");
                        sb.Append(m_and); //and
                        sb.Append(" " + flanker.unit.CharacterName + " ");
                        sb.Append(m_isOnly); // is only
                        sb.Append(" <b>" + flanker.angle.ToString("0.00") + "</b>. ");
                        sb.Append("(" + m_lessThan); // That is less than
                        sb.Append(" " + GetMinimalFlankingAngle(AmazingOuflankers(rule.Initiator, flanker.unit)) + " ");
                        sb.Append(m_notEnoughToDistract); // and not enough to distract
                        sb.Append(" " + target.CharacterName + " ");
                        if (FlankerInfo.Item3)
                            sb.Append(m_outsandingTeamwork + ")"); // even with outstandng teamwork
                        sb.Append(" " + m_notFlanking + "."); // This is not a flanking attack
                        sb.AppendLine();
                        sb.AppendLine();

                        return;
                    }

                }

                public static LocalizedString m_canNotBeFkaned = new() { Key = "Flanking_can_not_be_flanked" };
                public static LocalizedString m_distracts = new() { Key = "Flanking_distracts" };
                public static LocalizedString m_masterfulFeat = new() { Key = "Flanking_With_a_masterful_feat_of_teamwork" };
                public static LocalizedString m_while = new() { Key = "Flanking_while" };
                public static LocalizedString m_fromAnotherFlank = new() { Key = "Flanking_from_another_flank" };
                public static LocalizedString m_angleofAttacks = new() { Key = "Flanking_angle_of_attacks" };
                public static LocalizedString m_and = new() { Key = "Flanking_and" };
                public static LocalizedString m_isOnly = new() { Key = "Flanking_is_only" };
                public static LocalizedString m_lessThan = new() { Key = "Flanking_less_than" };
                public static LocalizedString m_notEnoughToDistract = new() { Key = "Flanking_not_enough_to_distract" };
                public static LocalizedString m_notFlanking = new() { Key = "Flanking_not_flanking_attack" };
                public static LocalizedString m_soloTactics = new() { Key = "Flanking_soloTactics" };
                public static LocalizedString m_improvedOutflank = new() { Key = "Flanking_improvedOutflank" };
                public static LocalizedString m_but = new() { Key = "Flanking_but" };
                public static LocalizedString m_outsandingTeamwork = new() { Key = "Flanking_outsandingTeamwork" };
            }

        }






    }

}
