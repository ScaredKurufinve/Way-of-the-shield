﻿using Kingmaker.Blueprints.Classes;
using Kingmaker.Blueprints.Items.Armors;
using Kingmaker.Designers.Mechanics.Facts;
using Kingmaker.UnitLogic.ActivatableAbilities;
using Kingmaker.UnitLogic.Buffs.Blueprints;
using Kingmaker.UnitLogic.FactLogic;
using System;
using static Way_of_the_shield.Main;
using static Way_of_the_shield.Utilities;


namespace Way_of_the_shield.NewFeatsAndAbilities
{
    [HarmonyPatch]
    public static class ShieldedDefense
    {
        [HarmonyPatch(typeof(BlueprintsCache), nameof(BlueprintsCache.Init))]
        public static void BlueprintCache_Init_Patch()
        {
            Comment.Log("Begin creating Shielded Defense");
            string circ = "when creating Shielded Defense";
            #region Create ShieldedDefenseEffectBuff
            BlueprintBuff ShieldedDefenseEffectBuff = new()
            {
                name = modName + "ShieldedDefenseVisibleBuff",
                AssetGuid = new(new Guid("29397505648a462a874872b132a00b75")),
                FxOnRemove = new(),
                FxOnStart = new(),
                m_Flags = BlueprintBuff.Flags.HiddenInUi
            };
            ShieldedDefenseEffectBuff.AddComponent(new AddMechanicsFeature() { m_Feature = MechanicsFeatureExtension.ForceDualWieldingPenalties });
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(ShieldedDefenseEffectBuff.AssetGuid, ShieldedDefenseEffectBuff);
            Comment.Log("Added the ShieldedDefenseEffectBuff blueprint to the cache.");
            #endregion
            #region Create ShieldedDefense main buff blueprint
            RetrieveBlueprint("6ffd93355fb3bcf4592a5d976b1d32a9", out BlueprintBuff FightDefensivelyBuff, "FightDefensivelyBuff");
            BlueprintBuff ShieldedDefenseVisibleBuff = new()
            {
                name = modName + "ShieldedDefenseVisibleBuff",
                AssetGuid = new(new Guid("807ca5b2501444aab22a0f08a64691e1")),
                m_DisplayName = new() { Key = "ShieldedDefenseActivatableAbility_DisplayName" },
                m_Description = new() { m_Key = "ShieldedDefenseActivatableAbility_Description" },
                m_DescriptionShort = new() { m_Key = "ShieldedDefenseActivatableAbility_ShortDescription" },
                m_Icon = ResourcesLibrary.TryGetBlueprint<BlueprintShieldType>("d1b05b901bab9524388ebfa0435902a6").Icon,
                FxOnRemove = new(),
                FxOnStart = new(),
                m_Flags = BlueprintBuff.Flags.StayOnDeath,
            };
            ShieldedDefenseVisibleBuff.AddComponent(new BuffExtraEffects()
            {
                m_CheckedBuff = FightDefensivelyBuff?.ToReference<BlueprintBuffReference>(),
                m_ExtraEffectBuff = ShieldedDefenseEffectBuff.ToReference<BlueprintBuffReference>()
            });
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(ShieldedDefenseVisibleBuff.AssetGuid, ShieldedDefenseVisibleBuff);
            Comment.Log("Added the ShieldedDefenseVisibleBuff blueprint to the cache.");
            #endregion
            #region Create ShieldedDefenseActivatableAbility blueprint
            BlueprintActivatableAbility ShieldedDefenseActivatableAbility = new()
            {
                name = modName + "ShieldedDefenseActivatableAbility",
                AssetGuid = new(new Guid("7ca07f3bdbf145c2a975b11d9690c0b3")),
                m_DisplayName = new() { Key = "ShieldedDefenseActivatableAbility_DisplayName" },
                m_Description = new() { m_Key = "ShieldedDefenseActivatableAbility_Description" },
                m_DescriptionShort = new() { m_Key = "ShieldedDefenseActivatableAbility_ShortDescription" },
                m_Icon = ResourcesLibrary.TryGetBlueprint<BlueprintShieldType>("d1b05b901bab9524388ebfa0435902a6").Icon,
                ActivationType = AbilityActivationType.Immediately,
                DeactivateImmediately = true,
                DoNotTurnOffOnRest = true,
                m_Buff = ShieldedDefenseVisibleBuff.ToReference<BlueprintBuffReference>(),
            };
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(ShieldedDefenseActivatableAbility.AssetGuid, ShieldedDefenseActivatableAbility);
            Comment.Log("Added the ShieldedDefenseActivatableAbility blueprint to the cache.");
            #endregion            
            if (!RetrieveBlueprint("cb8686e7357a68c42bdd9d4e65334633", out BlueprintFeature ShieldProficiency, "ShieldProficiency", circ)) goto skipShieldProficiency;
            ShieldProficiency.AddComponent(new AddFacts() { m_Facts = new BlueprintUnitFactReference[] { ShieldedDefenseActivatableAbility.ToReference<BlueprintUnitFactReference>() } });
            Comment.Log("Added ShieldedDefenseActivatableAbility to the ShieldProficiency blueprint.");
        skipShieldProficiency:
            if (!RetrieveBlueprint("82fbdd5eb5ac73b498c572cc71bda48f", out BlueprintFeature ELementalBastionFeature, "ELementalBastionFeature", circ)) goto skipELementalBastion;
            ELementalBastionFeature.AddComponent(new AddFacts() { m_Facts = new BlueprintUnitFactReference[] { ShieldedDefenseActivatableAbility.ToReference<BlueprintUnitFactReference>() } });
            Comment.Log("Added ShieldedDefenseActivatableAbility to the ELementalBastionFeature blueprint.");
        skipELementalBastion:
            if (!RetrieveBlueprint("94fe0ca10f17bf143a7d2bd2ab2acdda", out BlueprintFeature MythicPetEmptyFeature, "MythicPetEmptyFeature", circ)) goto skipMythicPet;
            MythicPetEmptyFeature.AddComponent(new AddFacts() { m_Facts = new BlueprintUnitFactReference[] { ShieldedDefenseActivatableAbility.ToReference<BlueprintUnitFactReference>() } });
            Comment.Log("Added ShieldedDefenseActivatableAbility to the MythicPetEmptyFeature blueprint.");
        skipMythicPet:;

        }
    }
}

