﻿using Kingmaker.Blueprints.Classes;
using Kingmaker.Blueprints.Items.Ecnchantments;
using Kingmaker.Blueprints.Items.Weapons;
using Kingmaker.Designers.EventConditionActionSystem.Actions;
using Kingmaker.Designers.Mechanics.Facts;
using Kingmaker.ElementsSystem;
using Kingmaker.UnitLogic.Abilities.Blueprints;
using Kingmaker.UnitLogic.Abilities.Components;
using Kingmaker.UnitLogic.Abilities.Components.Base;
using Kingmaker.UnitLogic.Abilities.Components.CasterCheckers;
using Kingmaker.UnitLogic.ActivatableAbilities;
using Kingmaker.UnitLogic.Buffs.Blueprints;
using Kingmaker.UnitLogic.Commands.Base;
using Kingmaker.UnitLogic.FactLogic;
using Kingmaker.UnitLogic.Mechanics;
using Kingmaker.UnitLogic.Mechanics.Components;
using Kingmaker.UnitLogic.Mechanics.Conditions;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using static Way_of_the_shield.Main;
using static Way_of_the_shield.Utilities;

namespace Way_of_the_shield.NewFeatsAndAbilities.SacredShieldFeatures
{
    public class SacredShieldBond
    {
        [HarmonyPatch(typeof(BlueprintsCache), nameof(BlueprintsCache.Init))]
        public static void CreateSacredShieldBond()
        {
            string circ = "when creating Sacred Shield bond";
            Sprite Icon = LoadIcon("");
            #region Create Shield Sacred Bond Switch Ability blueprint
            BlueprintAbility ShieldSacredBondSwitchAbillity = new()
            {
                AssetGuid = new(new Guid("61fd6fcec7664d67800cd8b2da12c31e")),
                name = modName + "_ShieldSacredBondSwitchAbillity",
                m_DisplayName = new LocalizedString() { Key = "ShieldSacredBondFeature_DisplayName" },
                m_Description = new LocalizedString() { Key = "ShieldSacredBondFeature_Description" },
                m_DescriptionShort = new LocalizedString() { Key = "ShieldSacredBondFeature_ShortDescription" },
                LocalizedDuration = new LocalizedString() { Key = "Empty"},
                LocalizedSavingThrow = new LocalizedString() { m_Key = "Empty"},
                m_Icon = Icon,
                ActionType = UnitCommand.CommandType.Standard,
                Range = AbilityRange.Personal,
                EffectOnAlly = AbilityEffectOnUnit.Helpful,
            };
            #region create temprorary enhancement enchants
            BlueprintWeaponEnchantment TemporaryWeaponEnhancement6 = new()
            {
                AssetGuid = new BlueprintGuid(new Guid("b35dc9414232480fae269110209bd736")),
                name = modName + "_TemporaryEnhancement6",
                m_EnchantName = new LocalizedString() { Key = "TemporaryEnhancement6_EnchantName" },
                m_Description = new LocalizedString() { Key = "TemporaryEnhancement6_EnchantNameescription" },
                m_EnchantmentCost = 6,
            };
            TemporaryWeaponEnhancement6.AddComponent(new WeaponEnhancementBonus() { EnhancementBonus = 6, Stack = true });
            TemporaryWeaponEnhancement6.AddToCache();
            BlueprintWeaponEnchantment TemporaryArmorEnhancement6 = new()
            {
                AssetGuid = new BlueprintGuid(new Guid("1d1d494f523f4c4ebcdb74793b336b3e")),
                name = modName + "_TemporaryArmorEnhancementBonus6",
                m_EnchantName = new LocalizedString() { Key = "TemporaryArmorEnhancementBonus6_EnchantName" },
                m_Description = new LocalizedString() { Key = "TemporaryArmorEnhancementBonus6_EnchantNameescription" },
                m_EnchantmentCost = 6,
            };
            TemporaryArmorEnhancement6.AddComponent(new ArmorEnhancementBonus() { EnhancementValue = 6});
            TemporaryArmorEnhancement6.AddComponent(new AdvanceArmorStats() { ArmorCheckPenaltyShift = 1 });
            TemporaryArmorEnhancement6.AddToCache();
            #endregion
            BlueprintArmorEnchantmentReference[] temporaryArmorEnchantsArray = new BlueprintArmorEnchantmentReference[5]
            {
                ResourcesLibrary.TryGetBlueprint<BlueprintArmorEnchantment>("1d9b60d57afb45c4f9bb0a3c21bb3b98")?.ToReference<BlueprintArmorEnchantmentReference>(),
                ResourcesLibrary.TryGetBlueprint<BlueprintArmorEnchantment>("d45bfd838c541bb40bde7b0bf0e1b684")?.ToReference<BlueprintArmorEnchantmentReference>(),
                ResourcesLibrary.TryGetBlueprint<BlueprintArmorEnchantment>("51c51d841e9f16046a169729c13c4d4f")?.ToReference<BlueprintArmorEnchantmentReference>(),
                ResourcesLibrary.TryGetBlueprint<BlueprintArmorEnchantment>("6a6a0901d799ceb49b33d4851ff72132")?.ToReference<BlueprintArmorEnchantmentReference>(),
                ResourcesLibrary.TryGetBlueprint<BlueprintArmorEnchantment>("15d7d6cbbf56bd744b37bbf9225ea83b")?.ToReference<BlueprintArmorEnchantmentReference>(),
            };
            BlueprintWeaponEnchantmentReference[] temporaryWeaponEnchantsArray = new BlueprintWeaponEnchantmentReference[5]
            {
                ResourcesLibrary.TryGetBlueprint<BlueprintWeaponEnchantment>("d704f90f54f813043a525f304f6c0050")?.ToReference<BlueprintWeaponEnchantmentReference>(),
                ResourcesLibrary.TryGetBlueprint<BlueprintWeaponEnchantment>("9e9bab3020ec5f64499e007880b37e52")?.ToReference<BlueprintWeaponEnchantmentReference>(),
                ResourcesLibrary.TryGetBlueprint<BlueprintWeaponEnchantment>("d072b841ba0668846adeb007f623bd6c")?.ToReference<BlueprintWeaponEnchantmentReference>(),
                ResourcesLibrary.TryGetBlueprint<BlueprintWeaponEnchantment>("a23bcee56c9fcf64d863dafedb369387")?.ToReference<BlueprintWeaponEnchantmentReference>(),
                ResourcesLibrary.TryGetBlueprint<BlueprintWeaponEnchantment>("746ee366e50611146821d61e391edf16")?.ToReference<BlueprintWeaponEnchantmentReference>(),
            };
            if (Settings.IsEnabled("BuffSacredShieldEnhacementArray"))
            {
                temporaryArmorEnchantsArray = temporaryArmorEnchantsArray.Append(TemporaryArmorEnhancement6.ToReference<BlueprintArmorEnchantmentReference>()).ToArray();
                temporaryWeaponEnchantsArray = temporaryWeaponEnchantsArray.Append(TemporaryWeaponEnhancement6.ToReference<BlueprintWeaponEnchantmentReference>()).ToArray();
            }
            ShieldSacredBondSwitchAbillity.AddComponent(
                new AbilityEffectRunAction()
                {
                    Actions = new()
                    {
                        Actions = new GameAction[1]
                        {
                            new Conditional()
                            {
                                ConditionsChecker = new()
                                {
                                    Conditions = new Condition[1]
                                    {
                                        new ContextConditionIsShieldEquipped()
                                    }
                                },
                                IfFalse = new ActionList()
                                {
                                    Actions = new GameAction[]{ }
                                },
                                IfTrue = new ActionList()
                                {
                                    Actions = new GameAction[]
                                    {
                                        new NewComponents.ContextActionShieldGeneralEnchantPool()
                                        {
                                            m_DefaultEnchantmentsArmor = temporaryArmorEnchantsArray,
                                            m_DefaultEnchantmentsWeapon = temporaryWeaponEnchantsArray,
                                            DurationValue = new ContextDurationValue()
                                            {
                                                Rate = DurationRate.Minutes,
                                                DiceType = DiceType.Zero,
                                                DiceCountValue = new(),
                                                BonusValue = new()
                                                {
                                                    ValueType = ContextValueType.Rank,
                                                    ValueRank = AbilityRankType.DamageBonus,
                                                }
                                            }
                                        }
                                    }
                                },
                            }
                        }
                    }
                });
            ShieldSacredBondSwitchAbillity.AddComponent(
                new ContextRankConfig()
                {
                    m_Progression = ContextRankProgression.AsIs,
                    m_BaseValueType = ContextRankBaseValueType.SummClassLevelWithArchetype,
                    Archetype = new BlueprintArchetypeReference() { deserializedGuid = new(new Guid("56F19F65E28B4C3FB03E425FB047E08A")) }
                });
            if (RetrieveBlueprint("7ff088ab58c69854b82ea95c2b0e35b4", out BlueprintAbility WeaponBondSwitchAbility, "WeaponBondSwitchAbility", circ))
            {
                if (WeaponBondSwitchAbility.Components.TryFind(c => c is AbilityResourceLogic, out BlueprintComponent ARL))
                    ShieldSacredBondSwitchAbillity.AddComponent(ARL);
                if (WeaponBondSwitchAbility.Components.TryFind(c => c is AbilityCasterAlignment, out BlueprintComponent ACA))
                    ShieldSacredBondSwitchAbillity.AddComponent(ACA);
                IEnumerable<BlueprintComponent> ASF = WeaponBondSwitchAbility.Components.Where(c => c is AbilitySpawnFx);
                foreach (BlueprintComponent component in ASF) ShieldSacredBondSwitchAbillity.AddComponent(component);
            };

            #endregion
            #region create Bashing enchantment
            BlueprintWeaponEnchantment BashingEnchantment = new()
            {
                AssetGuid = new BlueprintGuid(new Guid("c9534ca2e5274888ba61761a78945c52")),
                name = modName + "_BashingEnchantment",
                m_EnchantmentCost = 1,
                m_EnchantName = new() { Key = "BashingEnchantment_EnchantName" },
                m_Description = new() { Key = "BashingEnchantment_Description" }
            };
            BashingEnchantment.AddComponent(new MeleeWeaponSizeChange() { SizeCategoryChange = 3 });
            BashingEnchantment.AddToCache();
            if (RetrieveBlueprint("d7fb623f94b42304db03645c6fdef245", out BlueprintItemWeapon BashingShieldWeapon, "BashingShieldWeapon", circ))
            {
                BashingShieldWeapon.m_DamageDice = new(1, DiceType.D4);
                BashingShieldWeapon.m_Enchantments = BashingShieldWeapon.m_Enchantments.Append(BashingEnchantment.ToReference<BlueprintWeaponEnchantmentReference>()).ToArray();
            }

            #endregion
            #region Create Bashing bond
            BlueprintBuff BashingBondBuff = new()
            {
                AssetGuid = new BlueprintGuid(new Guid("9e24dd8ac237426aa30c00e7ec68e90f")),
                name = modName + "_BashingBondBuff",
                m_Flags = BlueprintBuff.Flags.HiddenInUi | BlueprintBuff.Flags.StayOnDeath,
                IsClassFeature = true,
            };
            BashingBondBuff.AddComponent(new AddBondProperty() { EnchantPool = EnchantPoolExtensions.DivineShield, m_Enchant = BashingEnchantment.ToReference<BlueprintItemEnchantmentReference>() });
            BashingBondBuff.AddToCache();
            BlueprintActivatableAbility BashingBondActivatableAbility = new()
            {
                AssetGuid = new BlueprintGuid(new Guid("3a1706ab6d984ca1b5ef4e3a41fe38e5")),
                name = modName + "_BashingBondActivatableAbility",
                m_DisplayName = new() { Key = "BashingBondActivatableAbility_DisplayName" },
                m_Description = new() { Key = "BashingBondActivatableAbility_Description" },
                m_Buff = BashingBondBuff.ToReference<BlueprintBuffReference>(),
                Group = ActivatableAbilityGroup.DivineWeaponProperty,
                DeactivateImmediately = true,
                ActivationType = AbilityActivationType.Immediately
            };
            BashingBondActivatableAbility.AddToCache();
            #endregion
            #region Create Arrow Deflecting bond

            #endregion
            #region Create Shield Sacred Bond feature blueprint
            RetrieveBlueprint("3683d1af071c1744185ff93cba9db10b", out BlueprintAbilityResource WeaponBondResourse, "WeaponBondResourse", circ);
            BlueprintFeature ShieldSacredBondFeature = new()
            {
                AssetGuid = new BlueprintGuid(new Guid("e02318fbf171403b9956b6dee9f5e6e5")),
                name = modName + "_ShieldSacredBondFeature",
                m_DisplayName = new LocalizedString() { Key = "ShieldSacredBondFeature_DisplayName" },
                m_Description = new LocalizedString() { Key = "ShieldSacredBondFeature_Description" },
                m_DescriptionShort = new LocalizedString() { Key = "ShieldSacredBondFeature_ShortDescription" },
                m_Icon = Icon,
                Ranks = 1,
                IsClassFeature = true,
            };
            if (WeaponBondResourse is not null) ShieldSacredBondFeature.AddComponent(new AddAbilityResources()
            {
                m_Resource = WeaponBondResourse.ToReference<BlueprintAbilityResourceReference>(),
                Amount = 0,
                RestoreAmount = true
            });
            ShieldSacredBondFeature.AddComponent(new AddFacts()
            {
                m_Facts = new BlueprintUnitFactReference[] 
                {
                    ShieldSacredBondSwitchAbillity.ToReference<BlueprintUnitFactReference>(),
                    BashingBondActivatableAbility.ToReference<BlueprintUnitFactReference>()
                }
            });
            ShieldSacredBondFeature.AddToCache();
            #endregion
        }
    }
}
