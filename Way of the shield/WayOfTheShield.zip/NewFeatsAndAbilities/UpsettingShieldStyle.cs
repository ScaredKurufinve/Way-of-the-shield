﻿using Kingmaker;
using Kingmaker.Armies.TacticalCombat;
using Kingmaker.Blueprints.Classes;
using Kingmaker.Blueprints.Classes.Prerequisites;
using Kingmaker.Blueprints.Classes.Selection;
using Kingmaker.Blueprints.Items.Armors;
using Kingmaker.Designers.Mechanics.Buffs;
using Kingmaker.Designers.Mechanics.Facts;
using Kingmaker.EntitySystem.Stats;
using Kingmaker.Items;
using Kingmaker.RuleSystem.Rules;
using Kingmaker.UnitLogic.Buffs.Blueprints;
using Kingmaker.RuleSystem.Rules.Damage;
using Kingmaker.UnitLogic;
using Kingmaker.UnitLogic.ActivatableAbilities;
using Kingmaker.UnitLogic.Buffs.Components;
using Kingmaker.UnitLogic.FactLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using static Way_of_the_shield.Main;
using static Way_of_the_shield.Utilities;

namespace Way_of_the_shield.NewFeatsAndAbilities
{
    [HarmonyPatch]
    public class UpsettingShieldStyle
    {

        public static HashSet<(string, string)> selections = new()
        {
            new ("247a4068296e8be42890143f451b4b45", "BasicFeatSelection"),
            new ("41c8486641f7d6d4283ca9dae4147a9f", "FighterFeatSelection"),
            new ("c5357c05cf4f8414ebd0a33e534aec50", "CrusaderFeat1"),
            new ("50dc57d2662ccbd479b6bc8ab44edc44", "CrusaderFeat10"),
            new ("2049abc955bf6fe41a76f2cb6ba8214a", "CrusaderFeat20"),
            new ("303fd456ddb14437946e344bad9a893b", "WarpriestFeatSelection"),
        };
        public class UpsettingShieldComponent : UnitBuffComponentDelegate, IInitiatorRulebookHandler<RuleDealDamage>
        {
            public static BlueprintFeature Strike = new();
            public static BlueprintFeature Vengeance = new();
            public static BlueprintBuff VengeanceBuff = new();
            public static BlueprintBuff StrikeBuff = new();
            public static BlueprintBuff StyleBuff = new();
            public static BlueprintBuff checker = new();

            public int checkerRanks = 1;

            public void OnEventAboutToTrigger(RuleDealDamage evt)
            {

            }
            public void OnEventDidTrigger(RuleDealDamage evt)
            {
                if (TacticalCombatHelper.IsActive) return;
                ItemEntityWeapon weapon = evt.DamageBundle.Weapon;
                if (!weapon.IsShield || weapon.Shield?.ArmorComponent.Blueprint.ProficiencyGroup != ArmorProficiencyGroup.Buckler) return;
                if (evt.Result < 1) return;
                if (Owner.Progression.Features.HasFact(Vengeance))
                {
                    evt.Target.Descriptor.AddBuff(VengeanceBuff, Owner, new TimeSpan?(new Rounds(1).Seconds), null);
                    Owner.Descriptor.AddBuff(checker, Owner, new TimeSpan?(new Rounds(1).Seconds), null).SetRank(checkerRanks);
                    return;
                }
                else if (Owner.Progression.Features.HasFact(Strike))
                {
                    evt.Target.Descriptor.AddBuff(StrikeBuff, Owner, new TimeSpan?(new Rounds(1).Seconds), null);
                    Owner.Descriptor.AddBuff(checker, Owner, new TimeSpan?(new Rounds(1).Seconds), null).SetRank(checkerRanks);
                    return;
                };
                evt.Target.Descriptor.AddBuff(StyleBuff, Owner, new TimeSpan?(new Rounds(1).Seconds), null);
            }
        }
        public class AoOOnFarMiss : UnitBuffComponentDelegate, IInitiatorRulebookHandler<RuleAttackWithWeapon>
        {
            public void OnEventAboutToTrigger(RuleAttackWithWeapon evt)
            {
            }
            public void OnEventDidTrigger(RuleAttackWithWeapon evt)
            {
                BlueprintBuff buff = m_FactToCheck.Get();
                if (!evt.Weapon.Blueprint.IsMelee ||
                    CheckBuff && (CheckOnOwner ? !Owner.Descriptor.Buffs.HasFact(m_FactToCheck.Get()) : evt.Target.Descriptor.Buffs.HasFact(m_FactToCheck.Get()))) return;
                UnitEntityData StylishDude = Buff.Context.MaybeCaster;
                if (CasterOnly && evt.Target != StylishDude) return;
                if (evt.AttackRoll.D20 + evt.AttackRoll.AttackBonus - evt.AttackRoll.TargetAC <= -5)
                {
                    Game.Instance.CombatEngagementController.ForceAttackOfOpportunity(StylishDude, evt.Initiator);
                    if (CheckBuff && ReduceBuffRanksAfterAOO)
                    {
                        UnitEntityData BuffOwner = CheckOnOwner ? Owner : StylishDude;
                        int rank = BuffOwner.Descriptor.Buffs.GetBuff(buff).Rank;
                        rank--;
                        if (rank < 1) BuffOwner.Descriptor.Buffs.RemoveFact(buff);
                    }
                };
            }

            public bool CheckBuff;
            public bool CheckOnOwner;
            public BlueprintBuffReference m_FactToCheck;
            public bool CasterOnly;
            public bool ReduceBuffRanksAfterAOO = true;
        }

        [HarmonyPatch(typeof(BlueprintsCache), nameof(BlueprintsCache.Init))]
        [HarmonyPostfix]
        public static void BlueprintsCache_Init_Patch()
        {
            Comment.Log("Entered Blueprint cache patch for Upsetting style");
            if (!RetrieveBlueprint("121811173a614534e8720d7550aae253", out BlueprintFeature ShieldBash, "ShieldBashFeature")) return;
            BlueprintFeatureReference ShieldBashReference = ShieldBash.ToReference<BlueprintFeatureReference>();
            if (!RetrieveBlueprint("121811173a614534e8720d7550aae253", out BlueprintFeature CombatReflexes, "ShieldBashFeature")) return;
            BlueprintFeatureReference CombatReflexesReference = CombatReflexes.ToReference<BlueprintFeatureReference>();
            BlueprintFeatureSelection selection;
            #region Create UpsettingShield buff for the activatable ability

            Comment.Log("Begin creating UpsettingShield buff for the activatable ability.");
            BlueprintBuff UpsettingShieldBuffMain = new()
            {
                AssetGuid = new BlueprintGuid(new Guid("dfcbc91d3c2d4f8685acf158dcb58815")),
                name = "Upsetting Shield Style Buff",
                m_DisplayName = new LocalizedString() { m_Key = "UpsettingShieldStyle_DisplayName" },
                m_Description = new LocalizedString() { m_Key = "UpsettingShieldStyle_Description" },
                m_DescriptionShort = new LocalizedString() { m_Key = "UpsettingShieldStyle_ShortDescription" },
                FxOnRemove = new(),
                FxOnStart = new(),
                m_Flags = BlueprintBuff.Flags.StayOnDeath,
                Stacking = StackingType.Replace,
                TickEachSecond = false,
                Frequency = Kingmaker.UnitLogic.Mechanics.DurationRate.Rounds,
                //m_Icon = 
            };
            UpsettingShieldBuffMain.AddComponent(new UpsettingShieldComponent());
            #endregion
            #region Create Upsetting Shield activatable ability
            Comment.Log("Begin creating UpsettingShield activatable ability blueprint");
            BlueprintActivatableAbility UpsettingShieldStyleAbility = new()
            {
                AssetGuid = new BlueprintGuid(new Guid("fc452aa2ff72401f943a133706b35acc")),
                name = "Upsetting Shield Style activatable ability - Way of the Shield",
                m_DisplayName = new LocalizedString() { m_Key = "UpsettingShieldStyle_DisplayName" },
                m_Description = new LocalizedString() { m_Key = "UpsettingShieldStyle_Description" },
                m_DescriptionShort = new LocalizedString() { m_Key = "UpsettingShieldStyle_ShortDescription" },
                m_Buff = UpsettingShieldBuffMain.ToReference<BlueprintBuffReference>(),
                Group = ActivatableAbilityGroup.CombatStyle,
                WeightInGroup = 1,
                ActivationType = AbilityActivationType.Immediately
            };
            UpsettingShieldStyleAbility.AddComponent(new DeactivateImmediatelyIfNoAttacksThisRound());
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(UpsettingShieldStyleAbility.AssetGuid, UpsettingShieldStyleAbility);
            #endregion
            #region Create UpsettingShield feature
            Comment.Log("Begin creating UpsettingShield feature blueprint");
            BlueprintFeature UpsettingShieldStyleFeature = new()
            {
                AssetGuid = new BlueprintGuid(new Guid("7da0bf0d789d4528b4c3b707eb98fbd2")),
                name = "Upsetting Shield Style feature - Way of the Shield",
                m_DisplayName = new LocalizedString() { m_Key = "UpsettingShieldStyle_DisplayName" },
                m_Description = new LocalizedString() { m_Key = "UpsettingShieldStyle_Description" },
                m_DescriptionShort = new LocalizedString() { m_Key = "UpsettingShieldStyle_ShortDescription" },
                Groups = new FeatureGroup[]
                {
                    FeatureGroup.CombatFeat,
                    FeatureGroup.Feat,
                    FeatureGroup.StyleFeat
                },
                HideInUI = false,
                HideInCharacterSheetAndLevelUp = false,
                HideNotAvailibleInUI = false,
                IsClassFeature = false,
                Ranks = 1,
                //m_Icon
            };
            UpsettingShieldStyleFeature.AddComponent(new PrerequisiteStatValue()
            {
                Stat = StatType.Dexterity,
                Value = 13,
                Group = Prerequisite.GroupType.All
            });
            UpsettingShieldStyleFeature.AddComponent(new PrerequisiteProficiency()
            {
                ArmorProficiencies = new ArmorProficiencyGroup[] { ArmorProficiencyGroup.Buckler },
                WeaponProficiencies = Array.Empty<WeaponCategory>(),
                Group = Prerequisite.GroupType.All
            });
            UpsettingShieldStyleFeature.AddComponent(new PrerequisiteIsPet() { Not = true, HideInUI = true, Group = Prerequisite.GroupType.All });
            UpsettingShieldStyleFeature.AddComponent(new AddFacts() { m_Facts = new BlueprintUnitFactReference[] { UpsettingShieldStyleAbility.ToReference<BlueprintUnitFactReference>() } });
            UpsettingShieldStyleFeature.AddComponent(new FeatureTagsComponent()
            {
                FeatureTags =
                FeatureTag.Attack |
                FeatureTag.Melee |
                FeatureTag.Style
            });
            UpsettingShieldStyleFeature.AddComponent(new AddMechanicsFeature() { m_Feature = MechanicsFeatureExtension.BucklerBash });
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(UpsettingShieldStyleFeature.AssetGuid, UpsettingShieldStyleFeature);
            BlueprintFeatureReference UpsettingShieldStyleReference = UpsettingShieldStyleFeature.ToReference<BlueprintFeatureReference>();
            foreach ((string guid, string name) in selections)
            {
                if (!RetrieveBlueprint(guid, out selection, name)) continue;
                else
                {
                    selection.m_AllFeatures = selection.m_AllFeatures.Append(UpsettingShieldStyleReference).ToArray();
                    Comment.Log("Added UpsettingShieldStyleFeature to the " + name + " blueprint.");
                }
            };
            #endregion
            #region Create UpsettingStrike feature
            Comment.Log("Begin creating Upsetting Strike feature blueprint");
            BlueprintFeature UpsettingStrikeFeature = new()
            {
                AssetGuid = new BlueprintGuid(new Guid("836dafe9db094691bce5dc0c6b0305ac")),
                name = "Upsetting Strike feature - Way of the Shield",
                m_DisplayName = new LocalizedString() { m_Key = "UpsettingStrike_DisplayName" },
                m_Description = new LocalizedString() { m_Key = "UpsettingStrike_Description" },
                m_DescriptionShort = new LocalizedString() { m_Key = "UpsettingStrike_ShortDescription" },
                Groups = new FeatureGroup[]
                {
                    FeatureGroup.CombatFeat,
                    FeatureGroup.Feat,
                    FeatureGroup.StyleFeat
                },
                HideInUI = false,
                HideInCharacterSheetAndLevelUp = false,
                HideNotAvailibleInUI = false,
                IsClassFeature = false,
                Ranks = 1,
                //m_Icon
            };
            UpsettingStrikeFeature.AddComponent(new PrerequisiteStatValue()
            {
                Stat = StatType.Dexterity,
                Value = 15,
                Group = Prerequisite.GroupType.All
            });
            UpsettingStrikeFeature.AddComponent(new PrerequisiteProficiency()
            {
                ArmorProficiencies = new ArmorProficiencyGroup[] { ArmorProficiencyGroup.Buckler },
                WeaponProficiencies = Array.Empty<WeaponCategory>(),
                Group = Prerequisite.GroupType.All
            });
            UpsettingStrikeFeature.AddComponent(new PrerequisiteFeature() { name = "Upsetting Shield Style Prerequisite", m_Feature = UpsettingShieldStyleFeature.ToReference<BlueprintFeatureReference>(), Group = Prerequisite.GroupType.All });
            UpsettingStrikeFeature.AddComponent(new PrerequisiteFeature() { name = "Shield Bash Prerequisite", m_Feature = ShieldBashReference, Group = Prerequisite.GroupType.All });
            UpsettingStrikeFeature.AddComponent(new PrerequisiteFeature() { name = "Combat Reflexes Prerequisite", m_Feature = CombatReflexesReference, Group = Prerequisite.GroupType.All });
            UpsettingStrikeFeature.AddComponent(new PrerequisiteIsPet() { Not = true, HideInUI = true });
            UpsettingStrikeFeature.AddComponent(new FeatureTagsComponent()
            {
                FeatureTags =
                FeatureTag.Attack |
                FeatureTag.Melee |
                FeatureTag.Style
            });
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(UpsettingStrikeFeature.AssetGuid, UpsettingStrikeFeature);
            BlueprintFeatureReference UpsettingStrikeFeatureReference = UpsettingStrikeFeature.ToReference<BlueprintFeatureReference>();
            UpsettingShieldStyleFeature.IsPrerequisiteFor ??= new();
            UpsettingShieldStyleFeature.IsPrerequisiteFor.Add(UpsettingStrikeFeatureReference);
            ShieldBash.IsPrerequisiteFor ??= new();
            ShieldBash.IsPrerequisiteFor.Add(UpsettingStrikeFeatureReference);
            CombatReflexes.IsPrerequisiteFor ??= new();
            CombatReflexes.IsPrerequisiteFor.Add(UpsettingStrikeFeatureReference);
            UpsettingShieldComponent.Strike = UpsettingStrikeFeature;
            foreach ((string guid, string name) in selections)
            {
                if (!RetrieveBlueprint(guid, out selection, name)) continue;
                else
                {
                    selection.m_AllFeatures = selection.m_AllFeatures.Append(UpsettingStrikeFeatureReference).ToArray();
                    Comment.Log("Added UpsettingStrikeFeature to the " + name + " blueprint.");
                }
            };
            #endregion
            #region Create UpsettingVengeance feature
            Comment.Log("Begin creating UpsettingVengeance feature blueprint");
            BlueprintFeature UpsettingVengeanceFeature = new()
            {
                AssetGuid = new BlueprintGuid(new Guid("c748ba6f94fb4dd68e5aebbe8562a80b")),
                name = "Upsetting Vengeance feature - Way of the Shield",
                m_DisplayName = new LocalizedString() { m_Key = "UpsettingVengeance_DisplayName" },
                m_Description = new LocalizedString() { m_Key = "UpsettingVengeance_Description" },
                m_DescriptionShort = new LocalizedString() { m_Key = "UpsettingVengeance_ShortDescription" },
                Groups = new FeatureGroup[]
                {
                    FeatureGroup.CombatFeat,
                    FeatureGroup.Feat,
                    FeatureGroup.StyleFeat
                },
                HideInUI = false,
                HideInCharacterSheetAndLevelUp = false,
                HideNotAvailibleInUI = false,
                IsClassFeature = false,
                Ranks = 1,
                //m_Icon
            };
            UpsettingVengeanceFeature.AddComponent(new PrerequisiteStatValue()
            {
                Stat = StatType.Dexterity,
                Value = 15,
                Group = Prerequisite.GroupType.All
            });
            UpsettingVengeanceFeature.AddComponent(new PrerequisiteProficiency()
            {
                ArmorProficiencies = new ArmorProficiencyGroup[] { ArmorProficiencyGroup.Buckler },
                WeaponProficiencies = Array.Empty<WeaponCategory>(),
                Group = Prerequisite.GroupType.All
            });
            UpsettingVengeanceFeature.AddComponent(new PrerequisiteFeature() { name = "Upsetting Shield Style Prerequisite", m_Feature = UpsettingShieldStyleFeature.ToReference<BlueprintFeatureReference>(), Group = Prerequisite.GroupType.All });
            UpsettingVengeanceFeature.AddComponent(new PrerequisiteFeature() { name = "Upsetting Strike Prerequisite", m_Feature = UpsettingStrikeFeature.ToReference<BlueprintFeatureReference>(), Group = Prerequisite.GroupType.All });
            UpsettingVengeanceFeature.AddComponent(new PrerequisiteFeature() { name = "Shield Bash Prerequisite", m_Feature = ShieldBashReference, Group = Prerequisite.GroupType.All });
            UpsettingVengeanceFeature.AddComponent(new PrerequisiteFeature() { name = "Combat Reflexes Prerequisite", m_Feature = CombatReflexesReference, Group = Prerequisite.GroupType.All });
            UpsettingVengeanceFeature.AddComponent(new PrerequisiteIsPet() { Not = true, HideInUI = true });
            UpsettingVengeanceFeature.AddComponent(new FeatureTagsComponent()
            {
                FeatureTags =
                FeatureTag.Attack |
                FeatureTag.Melee |
                FeatureTag.Style
            });
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(UpsettingVengeanceFeature.AssetGuid, UpsettingVengeanceFeature);
            BlueprintFeatureReference UpsettingVengeanceFeatureReference = UpsettingVengeanceFeature.ToReference<BlueprintFeatureReference>();
            UpsettingShieldStyleFeature.IsPrerequisiteFor ??= new();
            UpsettingShieldStyleFeature.IsPrerequisiteFor.Add(UpsettingVengeanceFeatureReference);
            UpsettingStrikeFeature.IsPrerequisiteFor ??= new();
            UpsettingStrikeFeature.IsPrerequisiteFor.Add(UpsettingVengeanceFeatureReference);
            ShieldBash.IsPrerequisiteFor ??= new();
            ShieldBash.IsPrerequisiteFor.Add(UpsettingVengeanceFeatureReference);
            CombatReflexes.IsPrerequisiteFor ??= new();
            CombatReflexes.IsPrerequisiteFor.Add(UpsettingVengeanceFeatureReference);
            UpsettingShieldComponent.Vengeance = UpsettingVengeanceFeature;
            foreach ((string guid, string name) in selections)
            {
                if (!RetrieveBlueprint(guid, out selection, name)) continue;
                else
                {
                    selection.m_AllFeatures = selection.m_AllFeatures.Append(UpsettingVengeanceFeatureReference).ToArray();
                    Comment.Log("Added UpsettingVengeanceFeature to the " + name + " blueprint.");
                }
            };
            #endregion
            #region Create checker buff
            BlueprintBuff checker = new()
            {
                AssetGuid = new BlueprintGuid(new Guid("725ff3821a1242a8bf9e15429319152d")),
                name = "Checker buff for the Upsetting Shield style - Way of the Shield",
                m_Flags = BlueprintBuff.Flags.HiddenInUi
            };
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(checker.AssetGuid, checker);
            UpsettingShieldComponent.checker = checker;
            BlueprintBuffReference checkerReference = checker.ToReference<BlueprintBuffReference>();
            #endregion
            #region Create Style buff
            Comment.Log("Begin creating the style buff for the Upsetting Shield component");
            BlueprintBuff UpsettingShieldBuff = new()
            {
                AssetGuid = new BlueprintGuid(new Guid("8256f265fae94c7a891a23e796d23956")),
                name = "Upsetting Shield buff = Way of the Shield",
                m_DisplayName = new() { Key = "UpsettingShieldEffect_DisplayName" },
                m_Description = new() { Key = "UpsettingShieldEffect_Description" },
                m_DescriptionShort = new() { Key = "UpsettingShieldEffect_ShortDescription" },
                FxOnRemove = new(),
                FxOnStart = new(),
                Stacking = StackingType.Summ,
                Frequency = Kingmaker.UnitLogic.Mechanics.DurationRate.Rounds,
            };
            UpsettingShieldBuff.AddComponent(new AttackBonusAgainstCaster()
            {
                Value = -2,
                Descriptor = ModifierDescriptor.UntypedStackable
            });
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(UpsettingShieldBuff.AssetGuid, UpsettingShieldBuff);
            UpsettingShieldComponent.StyleBuff = UpsettingShieldBuff;
            #endregion
            #region Create Strike buff
            Comment.Log("Begin creating the Strike buff for the Upsetting Shield component");
            BlueprintBuff UpsettingStrikeBuff = new()
            {
                AssetGuid = new BlueprintGuid(new Guid("8256f265fae94c7a891a23e796d23956")),
                name = "Upsetting Shield buff = Way of the Shield",
                m_DisplayName = new() { Key = "UpsettingStrikeEffect_DisplayName" },
                m_Description = new() { Key = "UpsettingStrikeEffect_Description" },
                m_DescriptionShort = new() { Key = "UpsettingStrikeEffectt_ShortDescription" },
                FxOnRemove = new(),
                FxOnStart = new(),
                Stacking = StackingType.Summ,
                Frequency = Kingmaker.UnitLogic.Mechanics.DurationRate.Rounds,
            };
            UpsettingStrikeBuff.AddComponent(new AttackBonusAgainstCaster()
            {
                Value = -2,
                Descriptor = ModifierDescriptor.UntypedStackable
            });
            UpsettingStrikeBuff.AddComponent(new AoOOnFarMiss() { CheckBuff = true, CheckOnOwner = false, m_FactToCheck = checkerReference, CasterOnly = true });
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(UpsettingShieldBuff.AssetGuid, UpsettingShieldBuff);
            UpsettingShieldComponent.StrikeBuff = UpsettingStrikeBuff;
            #endregion
            #region Create Vengeance Strike buff
            Comment.Log("Begin creating the Strike buff for the Upsetting Shield component");
            BlueprintBuff UpsettingVengeanceBuff = new()
            {
                AssetGuid = new BlueprintGuid(new Guid("8256f265fae94c7a891a23e796d23956")),
                name = "Upsetting Shield buff = Way of the Shield",
                m_DisplayName = new() { Key = "UpsettingVengeanceEffect_DisplayName" },
                m_Description = new() { Key = "UpsettingVengeaceEffect_Description" },
                m_DescriptionShort = new() { Key = "UpsettingVengeanceEffect_ShortDescription" },
                FxOnRemove = new(),
                FxOnStart = new(),
                Stacking = StackingType.Summ,
                Frequency = Kingmaker.UnitLogic.Mechanics.DurationRate.Rounds
            };
            UpsettingVengeanceBuff.AddComponent(new AddContextStatBonus()
            {
                Value = -2,
                Descriptor = ModifierDescriptor.UntypedStackable,
                Stat = StatType.AdditionalAttackBonus
            });
            UpsettingVengeanceBuff.AddComponent(new AoOOnFarMiss() { CheckBuff = true, CheckOnOwner = false, m_FactToCheck = checkerReference, CasterOnly = false });
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(UpsettingVengeanceBuff.AssetGuid, UpsettingVengeanceBuff);
            UpsettingShieldComponent.VengeanceBuff = UpsettingVengeanceBuff;
            #endregion
        }

    }
}
