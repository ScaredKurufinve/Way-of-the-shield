﻿using Kingmaker.Blueprints.Classes;
using Kingmaker.Designers.Mechanics.Facts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Way_of_the_shield.Utilities;
using static Way_of_the_shield.Main;

namespace Way_of_the_shield
{
    [HarmonyPatch]
    public static class ShieldWallFix
    {
        [HarmonyPrepare]
        public static bool Prepare()
        {
            if (!Settings.IsEnabled("ChangeShieldWall")) return false;
            else return true;
        }
        
        [HarmonyPatch(typeof(BlueprintsCache), nameof (BlueprintsCache.Init))]
        [HarmonyPostfix]
        public static void SubstituteShieldWallComponent()
        {
            if (!RetrieveBlueprint("8976de442862f82488a4b138a0a89907", out BlueprintFeature bpShieldWall, "ShieldWall", "when substituting the ShieldWall component")) return;
            
            bpShieldWall.ComponentsArray = bpShieldWall.Components.Where(c => c is not ShieldWall).ToArray();
            bpShieldWall.AddComponent(new NewComponents.ShieldWallNew() { Radius = 5, m_ShieldWallFact = bpShieldWall.ToReference<BlueprintUnitFactReference>() });
        }
    }
}
