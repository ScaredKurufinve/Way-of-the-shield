﻿using System;
using System.Collections.Generic;
using System.Diagnostics;


namespace Way_of_the_shield
{
    public class Settings
    {
        static Dictionary<string, bool> list = new();
        public static bool initialized = false;

        static public void Init()
        {
            Disable("Debug");
#if debug
Enable("Debug");
#endif
            Enable("AllowEquipNonProfficientItems");
            Enable("AllowGlaivesForShieldBrace");
            Enable("ForbidCloseFlanking");
            Enable("AllowCloseFlankingToEnemies");
            Enable("ConcealmentAttackBonusOnBackstab");
            Enable("DenyShieldBonusOnBackstab");
            Enable("FlatFootedOnBackstab");
            Enable("AddBucklerParry");
            Enable("AllowTwoHanded-as-OneHandedWhenBuckler");
            Enable("GiveImmediateRepositioningToTSS");
            Enable("RemoveTotalCoverFeatureFromTSS");
            Enable("AddSoftCoverDenialToImprovedPreciseStrike");
            Enable("ChangeShieldWall");
            Enable("BuffSacredShieldEnhacementArray");
            initialized = true;
        }

        static public void Enable(string SettingName)
        {
            if (list.ContainsKey(SettingName)) { list[SettingName] = true; }

            else { list.Add(SettingName, true); };
        }

        static public void Disable(string SettingName)
        {
            if (list.ContainsKey(SettingName)) { list[SettingName] = false; }

            else { list.Add(SettingName, false); };
        }

        static public bool IsDisabled(string SettingName)
        {
            if (list.TryGetValue(SettingName, out bool setting)) return !setting;
            else
            {

                StackTrace trace = new();
                StackFrame frame = trace.GetFrame(1);
                Main.Comment.Error(string.Format("Method {0} from Type {1} caleed for non-existant mod setting {2}", frame.GetMethod().ToString(), frame.GetType().ToString(), SettingName), Array.Empty<object>());
                return false;
            }
        }

        static public bool IsEnabled(string SettingName)
        {
            if (list.TryGetValue(SettingName, out bool setting)) return setting;
            else
            {

                StackTrace trace = new();
                StackFrame frame = trace.GetFrame(1);
                Main.Comment.Error(string.Format("Method {0} from Type {1} caleed for non-existant mod setting {2}", frame.GetMethod().ToString(), frame.GetType().ToString(), SettingName), Array.Empty<object>());
                return false;
            }
        }
    }


}
