﻿using Kingmaker;
using Kingmaker.Armies.TacticalCombat;
using Kingmaker.Blueprints.Items.Ecnchantments;
using Kingmaker.Blueprints.Root;
using Kingmaker.Blueprints.Root.Strings;
using Kingmaker.Blueprints.Root.Strings.GameLog;
using Kingmaker.EntitySystem.Stats;
using Kingmaker.Items;
using Kingmaker.RuleSystem.Rules;
using Kingmaker.UI;
using Kingmaker.UI.Common;
using Kingmaker.UnitLogic;
using Kingmaker.UnitLogic.FactLogic;
using Kingmaker.UnitLogic.Parts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;


namespace Way_of_the_shield
{
    public static class Backstab
    {
        public enum ArmorDenialType
        {
            IsTouch = 0,
            IsBrilliantEnergy = 1,
            IsBackstab = 2,
            IsSnipe = 5,
        }

        const float BackstabAngle = 55;
        public static readonly RulebookEvent.CustomDataKey Backstabkey = new("Backstab");
        public static readonly RulebookEvent.CustomDataKey ShieldBonusACDenied = new("ShieldBonusACDenied");


        //  [HarmonyPatch]
        //  public class RuleAttackRoll_Constructor_patch
        //  {
        //      
        //

        //      [HarmonyTargetMethods]
        //      public static IEnumerable<MethodBase> TargetMethods()
        //      {
        //         IEnumerable<MethodBase> result = typeof(RuleAttackRoll).GetConstructors();
        //#if debug
        //                Main.Comment.Log("RuleAttackRoll constructor patcher obtained" + result.Count().ToString() + "following methods: \n" + result.ToString());
        //#endif
        //                return result;
        //            }

        //      [HarmonyPostfix]
        //     public static void Postfix(UnitEntityData initiator, UnitEntityData target, RuleAttackRoll __instance)
        //           {
        //              Main.Comment.Log("Entered RuleAttackRoll constructor Postifx");
        //              float angle1 = initiator.Orientation;
        //              float angle2 = target.Orientation;
        //              if (angle1 - angle2 > 180) angle2 += 360;
        //              else if (angle2 - angle1 > 180) angle1 += 360;
        //              float angle_difference = Math.Abs(angle2 - angle1);

        //             bool sighted = false;
        //             List<(Feet, UnitConditionExceptions)> blindsight = target.Get<UnitPartConcealment>()?.m_BlindsightRanges;
        //             if (blindsight is not null)
        //             {
        //                 Feet f = 0.Feet();
        //                 foreach (ValueTuple<Feet, UnitConditionExceptions> valueTuple in blindsight)
        //                 {
        //                     if ((valueTuple.Item2 == null || !valueTuple.Item2.IsExceptional(target)) && f < valueTuple.Item1)
        //                    {
        //                        f = valueTuple.Item1;
        //                     }
        //                 }
        //                float num = initiator.View.Corpulence + target.View.Corpulence;
        //                if (initiator.DistanceTo(target) - num <= f.Meters)
        //                {
        //                     sighted = true;
        //                 }
        //             }
        //             bool backstab = angle_difference < BackstabAngle && !sighted;

        //             Main.Comment.Log(initiator.CharacterName + " attacks " + target.CharacterName + ". Angles are " + initiator.Orientation + " and " + target.Orientation + ", difference is " + angle_difference + ". Sighted is " + sighted + "Backstab is " + backstab + ".");

        //            if (backstab) __instance.SetCustomData(key, true);
        //        }


        //  }

        //  [HarmonyPatch(typeof(RuleAttackRoll), nameof(RuleAttackRoll.OnTrigger))]
        //  public static class RuleAttackRoll_OnTrigger_patch
        //  {
        //      [HarmonyTranspiler]
        //      public static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
        //      {
        //
        //          Main.Comment.Log("Transpiling RuleAttackRoll.OnTrigger");
        //          ConstructorInfo info1 = typeof(RuleCalculateAC).GetConstructor(new Type[] { typeof(UnitEntityData),
        //                                                                                      typeof(UnitEntityData),
        //                                                                                      typeof(AttackType)
        //         });

        //         if (info1 is null) { Main.Comment.Log("could not find the constructor for RuleCalculateAC. Abort Transpiling"); return instructions; }
        //#if debug
        //                else Main.Comment.Log("found the constructor for RuleCalculateAC");
        //#endif

        //                CodeInstruction[] toSearch1 =
        //                {
        //                   new CodeInstruction(OpCodes.Newobj, info1)
        //               };


        //              ConstructorInfo info2 = typeof(RuleCalculateAttackBonus).GetConstructor(new Type[] {typeof(UnitEntityData),
        //                                                                                                  typeof(UnitEntityData),
        //                                                                                                  typeof(RuleCalculateWeaponStats),
        //                                                                                                  typeof(int)
        //              });
        //
        //               if (info2 is null) { Main.Comment.Log("could not find the constructor for RuleCalculateAttackBonus. Abort Transpiling"); ; return instructions; }
        //#if debug
        //                else Main.Comment.Log("found the constructor for RuleCalculateAttackBonus");
        //#endif


        //               CodeInstruction[] toSearch2 =
        //              {
        //                  new CodeInstruction(OpCodes.Newobj,info2)
        //              };


        //             CodeInstruction[] toInsert = { new CodeInstruction(OpCodes.Dup),
        //                                           new CodeInstruction(OpCodes.Ldarg_0),
        //                                            new CodeInstruction(OpCodes.Call, nameof(RuleAttackRoll_OnTrigger_patch.PutBackstabIntoDependantRules))
        //                                          };




        //            int index = -1;
        //            index = Utilities.IndexFinder(instructions, toSearch1);


        //           if (index == -1)
        //           {
        //               Main.Comment.Log("did not find the index for constructing RuleCalculateAC"); Main.Comment.Log("");
        //              return instructions;
        //          };
        //          List<CodeInstruction> result = instructions.ToList();
        //          result.InsertRange(index, toInsert);

        //          index = -1;
        //          index = Utilities.IndexFinder(result, toSearch2);



        //          if (!(index == -1)) result.InsertRange(index, toInsert);
        //           else { Main.Comment.Log("did not find the index for constructing RuleCalculateAttackBonus"); Main.Comment.Log(""); }
        //#if debug
        //             Main.Comment.Log("");
        //             foreach (CodeInstruction i in result) Main.Comment.Log(i.ToString());
        //             Main.Comment.Log("");
        //#endif

        //         if (index == -1) return instructions;
        //         return result;

        //    }

        //      private static void PutBackstabIntoDependantRules(RulebookEvent evt, RuleAttackRoll attack)
        //     {
        //         Main.Comment.Log("Entered PutBackstabIntoDependantRules");
        //         if (attack.TryGetCustomData(key, out bool backstab)) evt.SetCustomData(key, backstab);
        //     }


        //   }

        [HarmonyPatch(typeof(RuleCalculateAttackBonus), nameof(RuleCalculateAttackBonus.OnTrigger))]
        public static class RuleCalculateAttackBonus_OnTrigger_patch
        {
            [HarmonyTranspiler]
            public static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
            {
                Main.Comment.Log("");
                Main.Comment.Log("Entered the transpiler RuleCalculateAttackBonus_OnTrigger_patch");
                List<CodeInstruction> _instructions = instructions.ToList();

                int i2 = Utilities.IndexFinder(
                    instructions,
                    new CodeInstruction[]
                    {
                        new CodeInstruction(OpCodes.Ldc_I4_0),
                        new CodeInstruction(OpCodes.Call, typeof(UnitPartConcealment).GetMethod(nameof(UnitPartConcealment.Calculate))),
                        new CodeInstruction(OpCodes.Ldc_I4_2)
                    },
                    true);
                if (i2 == -1) { Main.Comment.Log("i2 = " + i2); return instructions; };

                _instructions[i2 + 1].operand = typeof(Backstab).GetMethod(nameof(Backstab.CalculateConcealment));
                List<CodeInstruction> toInsert = new() { new CodeInstruction(OpCodes.Ldarg_0), };
                _instructions.InsertRange(i2, toInsert);

                for (int i = 0; i < 10; i++) { Main.Comment.Log(_instructions[i].ToString()); };
                Main.Comment.Log("");

                return _instructions;
            }
        }

        [HarmonyPatch(typeof(RuleCalculateAC), nameof(RuleCalculateAC.OnTrigger))]
        public static class RuleCalculateAC_OnTrigger_patch
        {

            public static RuleCalculateAC rule;

            [HarmonyPrefix]
            public static void Prefix(RuleCalculateAC __instance)
            {
                rule = __instance;
            }

            [HarmonyPatch(typeof(RuleCheckTargetFlatFooted), nameof(RuleCheckTargetFlatFooted.OnTrigger))]
            public static class RuleCheckTargetFlatFooted_OnTrigger_patch
            {

                [HarmonyPrefix]
                public static void Prefix(RuleCheckTargetFlatFooted __instance)
                {
                    if (!TacticalCombatHelper.IsActive)
                    {
                        __instance.IsFlatFooted = ((CalculateConcealment(__instance.Target, __instance.Initiator, rule, false) == Concealment.Total && !__instance.IgnoreConcealment)
                            || __instance.ForceFlatFooted
                            || (!__instance.Target.CombatState.CanActInCombat && !__instance.IgnoreVisibility)
                            || __instance.Target.Descriptor.State.IsHelpless
                            || __instance.Target.Descriptor.State.HasCondition(UnitCondition.Stunned)
                            || (!__instance.Target.Memory.Contains(__instance.Initiator) && !__instance.IgnoreVisibility)
                            || __instance.Target.Descriptor.State.HasCondition(UnitCondition.LoseDexterityToAC)
                            || ((__instance.Target.Descriptor.State.HasCondition(UnitCondition.Shaken)
                            || __instance.Target.Descriptor.State.HasCondition(UnitCondition.Frightened)) && __instance.Initiator.Descriptor.State.Features.ShatterDefenses));
                        return;
                    }
                    __instance.IsFlatFooted = false;
                }

                //[HarmonyTranspiler]
                //public static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
                //{
                //    Main.Comment.Log("Entered RuleCheckTargetFlatFooted.OnTrigger transpiler");
                //    List<CodeInstruction> _instructions = instructions.ToList();
                //    int index = _instructions.FindIndex(instruction => instruction.Calls(typeof(UnitPartConcealment).GetMethod(nameof(UnitPartConcealment.Calculate))));
                //   if (index == -1) { Main.Comment.Log("Failed to find the index of UnitPartConcealment.Calculate in RuleCheckTargetFlatFooted.OnTrigger"); return instructions; };
                //   _instructions[index].operand = typeof(Backstab).GetMethod(nameof(CalculateConcealment));
                //   _instructions.Insert(index - 1, new CodeInstruction(OpCodes.Ldsfld, typeof(RuleCalculateAC_OnTrigger_patch).GetField(nameof(rule))));


                //   foreach (CodeInstruction instruction in _instructions)  Main.Comment.Log(instruction.ToString());
                //   return _instructions;
                //}



                [HarmonyPostfix]
                public static void Postfix()
                {
                    rule = null;
                }
            }


            public static int CalculateACResult(RuleCalculateAC rule)
            {

                if (rule.IsTargetFlatFooted)
                {
                    if (rule.AttackType.IsTouch()) return rule.Target.Stats.AC.FlatFootedTouch;
                    else if (rule.BrilliantEnergy != null) return rule.Target.Stats.AC.FlatFooted - RuleCalculateAC.CalculateArmorAndShieldBonuses(rule.Target);
                    else if (((rule.TryGetCustomData(ShieldBonusACDenied, out bool shieldDenied) && shieldDenied)) || (rule.TryGetCustomData(Backstabkey, out bool backstab) && Settings.IsEnabled("DenyShieldBonusOnBackstab") && backstab)) return rule.Target.Stats.AC.FlatFooted - CalculateShieldBonuses(rule.Target);
                    else return rule.Target.Stats.AC.FlatFooted;
                }
                else
                {
                    if (rule.AttackType.IsTouch()) return rule.Target.Stats.AC.Touch;
                    else if (rule.BrilliantEnergy != null) return rule.Target.Stats.AC - RuleCalculateAC.CalculateArmorAndShieldBonuses(rule.Target);
                    else if (rule.Initiator.Get<MechanicsFeatureExtension.MechanicsFeatureExtensionPart>()?.ShieldDenied || (rule.TryGetCustomData(ShieldBonusACDenied, out bool shieldDenied) && shieldDenied) || (rule.TryGetCustomData(Backstabkey, out bool backstab) && Settings.IsEnabled("DenyShieldBonusOnBackstab") && backstab)) return rule.Target.Stats.AC - CalculateShieldBonuses(rule.Target);
                    else return rule.Target.Stats.AC;
                }
            }

            [HarmonyTranspiler]
            public static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
            {
                Main.Comment.Log("Entered RuleCalculateAC.OnTrigger transpiler");
                List<CodeInstruction> _instructions = instructions.ToList();

                CodeInstruction[] toSearch_1 = new CodeInstruction[]
                {
                    new CodeInstruction(OpCodes.Ldarg_0),
                    CodeInstruction.Call(typeof(RuleCalculateAC), typeof(RuleCalculateAC).GetProperty(nameof(RuleCalculateAC.IsTargetFlatFooted)).GetMethod.Name),
                    new CodeInstruction(OpCodes.Brtrue_S)
                };

                CodeInstruction[] toSearch_2 = new CodeInstruction[]
                {
                    CodeInstruction.Call(typeof(RuleCalculateAC), typeof(RuleCalculateAC).GetProperty(nameof(RuleCalculateAC.Result)).SetMethod.Name),
                    new CodeInstruction(OpCodes.Ldarg_0),
                   // new CodeInstruction(OpCodes.Ldfld, typeof(RuleCalculateAC).GetField(nameof(RuleCalculateAC.Target)))
                };

                int index1 = Utilities.IndexFinder(instructions, toSearch_1, true);
                int index2 = Utilities.IndexFinder(instructions, toSearch_2, true);
                if (index1 == -1) { Main.Comment.Log("Failed to find Index1"); return instructions; };
                if (index2 == -1) { Main.Comment.Log("Failed to find Index2"); return instructions; };

                _instructions.RemoveRange(index1, index2 - index1);

                _instructions.InsertRange(index1, new CodeInstruction[]
                                                  {
                                                      new CodeInstruction(OpCodes.Ldarg_0),
                                                      CodeInstruction.Call(typeof(RuleCalculateAC_OnTrigger_patch), typeof(RuleCalculateAC_OnTrigger_patch).GetMethod(nameof(RuleCalculateAC_OnTrigger_patch.CalculateACResult)).Name)
                                                  }
                );


                CodeInstruction[] toSearchBrilliant = new CodeInstruction[]
                {
                    new CodeInstruction(OpCodes.Ldarg_0),
                    CodeInstruction.Call(typeof(RuleCalculateAC), typeof(RuleCalculateAC).GetProperty(nameof(RuleCalculateAC.BrilliantEnergy)).GetMethod.Name),
                    new CodeInstruction(OpCodes.Brfalse_S),
                    new CodeInstruction(OpCodes.Ldarg_0),
                    new CodeInstruction(OpCodes.Ldarg_0),
                    new CodeInstruction(OpCodes.Ldfld),
                    CodeInstruction.Call(typeof(RuleCalculateAC), nameof(RuleCalculateAC.CalculateArmorAndShieldBonuses)),
                    new CodeInstruction(OpCodes.Neg),
                    new CodeInstruction(OpCodes.Ldarg_0),
                    CodeInstruction.Call(typeof(RuleCalculateAC), typeof(RuleCalculateAC).GetProperty(nameof(RuleCalculateAC.BrilliantEnergy)).GetMethod.Name),
                    new CodeInstruction(OpCodes.Ldc_I4_S, 25),
                };

                int indexBrilliant = Utilities.IndexFinder(_instructions, toSearchBrilliant, true);
                if (index1 == -1) { Main.Comment.Log("Failed to find Index1"); return instructions; };

                _instructions[indexBrilliant].MoveLabelsTo(_instructions[indexBrilliant + toSearchBrilliant.Length + 1]);
                _instructions.RemoveRange(indexBrilliant, toSearchBrilliant.Length + 1);


                foreach (CodeInstruction inst in _instructions) Main.Comment.Log(inst.ToString());
                return _instructions;

            }


        }

        [HarmonyPatch(typeof(AttackLogMessage), nameof(AttackLogMessage.AppendArmorClassBreakdown))]
        public static class AppendArmorClassBreakdown_Patch
        {

            public static string BrilliantEnergy_Name = ResourcesLibrary.TryGetBlueprint<BlueprintWeaponEnchantment>("66e9e299c9002ea4bb65b6f300e43770").m_EnchantName;


            [HarmonyPrefix]
            public static bool Prefix(StringBuilder sb, RuleCalculateAC rule, AttackLogMessage __instance)
            {
                if (Settings.IsEnabled("Debug"))
                    Main.Comment.Log("Entered AppendArmorClassBreakdown_Patch");

                if (rule == null)
                {
                    return false;
                }
                bool isTargetFlatFooted = rule.IsTargetFlatFooted;
                bool touch = rule.AttackType.IsTouch();
                bool stab = rule.TryGetCustomData(Backstabkey, out bool backstab) && backstab;
                if (Settings.IsEnabled("Debug"))
                    Main.Comment.Log("Stab is " + stab);
                bool Brilliant = rule.BrilliantEnergy is not null;
                sb.Append("<b>").Append(__instance.ArmorClassBreakdown).Append(": ").Append(rule.Result);
                if (isTargetFlatFooted || touch || stab || Brilliant)
                {
                    sb.Append(" (");
                    if (isTargetFlatFooted)
                    {
                        sb.Append(__instance.Flatfooted);
                        if (touch || stab || Brilliant)
                        {
                            sb.Append(", ");
                        }
                    }
                    if (touch)
                    {
                        sb.Append(__instance.Touch);
                        if (stab)
                        {
                            sb.Append(", ");
                        }
                    }
                    else if (Brilliant)
                    {
                        sb.Append(BrilliantEnergy_Name);
                        if (stab)
                        {
                            sb.Append(", ");
                        }
                    }
                    if (stab)
                    {
                        sb.Append(LocalizedTexts.Instance.BonusSources.GetText(Utilities.BonusTypeExtenstions.GetBonusType(161)));
                    }

                    sb.Append(")");
                }
                sb.Append("</b>\n");
                BonusSourceStrings bonusSources = LocalizedTexts.Instance.BonusSources;
                sb.Append(bonusSources.ArmorClassBase).Append(": ").Append(rule.Target.Stats.AC.BaseValue).Append('\n');
                StatModifiersBreakdown.AddBonusSources(rule.AllBonuses);
                bool ShieldDenial = (stab && Settings.IsEnabled("DenyShieldBonusOnBackstab")) || rule.Initiator.Get<MechanicsFeatureExtension.MechanicsFeatureExtensionPart>()?.ShieldDenied || ((rule.TryGetCustomData(ShieldBonusACDenied, out bool shieldDenied) && shieldDenied));
                AddArmorClassModifiers(rule.Target.Stats.AC, isTargetFlatFooted, touch, Brilliant, ShieldDenial, false);
                sb.AppendModifiersBreakdown("");
                //rule.TryGetCustomData(ShieldBonusACDenied, out bool check);
                if (Settings.IsEnabled("Debug"))
                    Main.Comment.Log(rule.Initiator.CharacterName + " attacks " + rule.Target.CharacterName + ", ShieldDenial is " + ShieldDenial + ".");
                return false;
            }


            public static void AddArmorClassModifiers(ModifiableValueArmorClass acStat, bool flatfooted, bool touch, bool BrilliantEnergy, bool shieldDenied, bool ignoreDexterityBonus = false)
            {
                foreach (ModifiableValue.Modifier modifier in acStat.GetDisplayModifiers())
                {
                    if (modifier.ModValue != 0
                        && (!flatfooted || ModifiableValueArmorClass.FilterAllowedForFlatFooted(modifier))
                        && (!touch || ModifiableValueArmorClass.FilterAllowedForTouch(modifier))
                        && (!BrilliantEnergy || FilterAllowedForBrilliantEnergy(modifier))
                        && (!shieldDenied || !ModifiableValueArmorClass.FilterIsShield(modifier))
                        && (!ignoreDexterityBonus || modifier.ModDescriptor != ModifierDescriptor.DexterityBonus))
                    {
                        ModifierDescriptor descriptor = (modifier.ModDescriptor != ModifierDescriptor.None) ? modifier.ModDescriptor : ModifierDescriptor.Other;
                        IUIDataProvider source = modifier.Source;
                        IUIDataProvider bonusSource = source ?? modifier.ItemSource;
                        StatModifiersBreakdown.AddBonus(modifier.ModValue, bonusSource, descriptor);
                    }
                }
            }


        }


        public static readonly Func<ModifiableValue.Modifier, bool> FilterAllowedForBrilliantEnergy = (m =>
        {
            ModifierDescriptor modDescriptor = m.ModDescriptor;
            return !(ModifiableValueArmorClass.FilterIsShield(m) || modDescriptor == ModifierDescriptor.Armor || modDescriptor == ModifierDescriptor.ArmorEnhancement || modDescriptor == ModifierDescriptor.Focus);
        });
        public static int CalculateShieldBonuses(UnitEntityData unit)
        {
            int num = 0;
            foreach (ModifiableValue.Modifier modifier in unit.Stats.AC.Modifiers)
            {
                if (!ModifiableValueArmorClass.FilterIsShield(modifier)) num = +modifier.ModValue;
            }
            return num;

        }
        public static Concealment CalculateConcealment(UnitEntityData initiator, UnitEntityData target, RulebookEvent rule, bool attack = false)
        {
            float angle1 = initiator.Orientation;
            float angle2 = target.Orientation;
            if (angle1 - angle2 > 180) angle2 += 360;
            else if (angle2 - angle1 > 180) angle1 += 360;
            float angle_difference = Math.Abs(angle2 - angle1);
            bool backstab = angle_difference < BackstabAngle;
            //Main.Comment.Log(target.CharacterName + " approaches " + initiator.CharacterName + ". Orientation angles are " + initiator.Orientation + " and " + target.Orientation + ", difference is " + angle_difference + ". Backstab is " + backstab + ".");
            if (Settings.IsEnabled("DenyShieldBonusOnBackstab") || Settings.IsEnabled("FlatFootedOnBackstab")) { rule?.SetCustomData(Backstabkey, backstab); };


            UnitPartConcealment unitPartConcealment = initiator.Get<UnitPartConcealment>();
            UnitPartConcealment unitPartConcealment2 = target.Get<UnitPartConcealment>();
            if (unitPartConcealment != null && unitPartConcealment.IgnoreAll)
            {
                return Concealment.None;
            }
            if ((unitPartConcealment?.m_BlindsightRanges) != null)
            {
                Feet f = 0.Feet();
                foreach (ValueTuple<Feet, UnitConditionExceptions> valueTuple in unitPartConcealment.m_BlindsightRanges)
                {
                    if ((valueTuple.Item2 == null || !valueTuple.Item2.IsExceptional(target)) && f < valueTuple.Item1)
                    {
                        f = valueTuple.Item1;
                    }
                }
                float num = initiator.View.Corpulence + target.View.Corpulence;
                if (initiator.DistanceTo(target) - num <= f.Meters)
                {
                    return Concealment.None;
                }
            }

            if (backstab && Settings.IsEnabled("FlatFootedOnBackstab")) return Concealment.Total;

            Concealment concealment = (unitPartConcealment2 != null && unitPartConcealment2.IsConcealedFor(initiator)) ? Concealment.Total : Concealment.None;
            if (target.Descriptor.State.HasCondition(UnitCondition.Invisible) && (!initiator.Descriptor.State.HasCondition(UnitCondition.SeeInvisibility) || !initiator.Descriptor.State.GetConditionExceptions(UnitCondition.SeeInvisibility).Any((UnitConditionExceptions _exception) => _exception == null || !_exception.IsExceptional(target))))
            {
                concealment = Concealment.Total;
            }
            if (concealment < Concealment.Total && (unitPartConcealment2?.m_Concealments) != null)
            {
                foreach (UnitPartConcealment.ConcealmentEntry concealmentEntry in unitPartConcealment2.m_Concealments)
                {
                    if (!concealmentEntry.OnlyForAttacks || attack)
                    {
                        if (concealmentEntry.DistanceGreater > 0.Feet())
                        {
                            float num2 = initiator.DistanceTo(target);
                            float num3 = initiator.View.Corpulence + target.View.Corpulence;
                            if (num2 <= concealmentEntry.DistanceGreater.Meters + num3)
                            {
                                continue;
                            }
                        }
                        if (concealmentEntry.RangeType != null)
                        {
                            RuleAttackRoll ruleAttackRoll = Rulebook.CurrentContext.LastEvent<RuleAttackRoll>();
                            ItemEntityWeapon itemEntityWeapon = (ruleAttackRoll != null) ? ruleAttackRoll.Weapon : initiator.GetFirstWeapon();
                            if (itemEntityWeapon == null || !concealmentEntry.RangeType.Value.IsSuitableWeapon(itemEntityWeapon))
                            {
                                continue;
                            }
                        }
                        if ((concealmentEntry.Descriptor == ConcealmentDescriptor.Blur || concealmentEntry.Descriptor == ConcealmentDescriptor.Displacement) && initiator.Descriptor.State.HasCondition(UnitCondition.TrueSeeing))
                        {
                            IEnumerable<UnitConditionExceptions> source = initiator.Descriptor.State.GetConditionExceptions(UnitCondition.TrueSeeing).EmptyIfNull<UnitConditionExceptions>();
                            if (source.Any(_exception =>
                            {
                                UnitConditionExceptionsTargetHasFacts unitConditionExceptionsTargetHasFacts = _exception as UnitConditionExceptionsTargetHasFacts;
                                return _exception as UnitConditionExceptionsTargetHasFacts == null || !unitConditionExceptionsTargetHasFacts.IsExceptional(target);
                            }))
                            {
                                continue;
                            }
                        }
                        concealment = UnitPartConcealment.Max(concealment, concealmentEntry.Concealment);
                    }
                }
            }
            if (unitPartConcealment2 != null && unitPartConcealment2.Disable)
            {
                concealment = Concealment.None;
            }
            if (initiator.Descriptor.State.HasCondition(UnitCondition.PartialConcealmentOnAttacks))
            {
                concealment = Concealment.Partial;
            }
            if (initiator.Descriptor.State.HasCondition(UnitCondition.Blindness))
            {
                concealment = Concealment.Total;
            }
            if (concealment == Concealment.None && Game.Instance.Player.Weather.ActualWeather >= BlueprintRoot.Instance.WeatherSettings.ConcealmentBeginsOn)
            {
                RuleAttackRoll ruleAttackRoll2 = Rulebook.CurrentContext.LastEvent<RuleAttackRoll>();
                ItemEntityWeapon itemEntityWeapon2 = (ruleAttackRoll2 != null) ? ruleAttackRoll2.Weapon : initiator.GetFirstWeapon();
                if (itemEntityWeapon2 != null && WeaponRangeType.Ranged.IsSuitableWeapon(itemEntityWeapon2))
                {
                    concealment = Concealment.Partial;
                }
            }
            if (unitPartConcealment != null && unitPartConcealment.IgnorePartial && concealment == Concealment.Partial)
            {
                concealment = Concealment.None;
            }
            if (unitPartConcealment != null && unitPartConcealment.TreatTotalAsPartial && concealment == Concealment.Total)
            {
                concealment = Concealment.Partial;
            }
            return concealment;
        }

    }
}
