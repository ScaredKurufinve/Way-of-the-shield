﻿using Kingmaker.Items;
using Kingmaker.Items.Slots;
using Kingmaker.Blueprints.Classes;
using Kingmaker.Blueprints.Items.Armors;
using Kingmaker.Blueprints.Items.Shields;
using Kingmaker.Blueprints.Items.Weapons;
using Kingmaker.RuleSystem.Rules;
using Kingmaker.UnitLogic;
using Kingmaker.UnitLogic.ActivatableAbilities;
using Kingmaker.UnitLogic.ActivatableAbilities.Restrictions;
using Kingmaker.UnitLogic.Buffs.Blueprints;
using Kingmaker.UnitLogic.FactLogic;
using System;
using System.Linq;
using Way_of_the_shield.NewComponents;
using static Way_of_the_shield.Main;
using static Way_of_the_shield.Utilities;

namespace Way_of_the_shield
{
    [HarmonyPatch]
    public static class BoringBucklerTweaks
    {

        public class Buckler1h_Component : CanUse2hWeaponAs1hBase, IInitiatorRulebookHandler<RuleCalculateAttackBonusWithoutTarget>, IInitiatorRulebookHandler<RuleAttackWithWeapon>
        {
            public static BlueprintBuff ShieldForbiddance;
            //static Buckler1h_Component()
            //{
            //    ShieldForbiddance = ResourcesLibrary.TryGetBlueprint<BlueprintBuff>("414f40680af64050a2a9dde3dede32ac");
            //   if (ShieldForbiddance is not null) return;
            //    ShieldForbiddance = new()
            //    {
            //        AssetGuid = new BlueprintGuid(new Guid("414f40680af64050a2a9dde3dede32ac")),
            //        name = "WayOfTheShield_ForbidShieldACforOneTurn",
            //        FxOnRemove = new(),
            //        m_Flags = BlueprintBuff.Flags.HiddenInUi
            //   };
            //    ShieldForbiddance.AddComponent(new AddMechanicsFeature() {m_Feature = MechanicsFeatureExtension.ShieldDenied });

            //}

            public override bool CanBeUsedAs2h(ItemEntityWeapon weapon)
            {
                return true;
            }

            public override bool CanBeUsedOn(ItemEntityWeapon weapon)
            {
                if (weapon is null) return false;
                if (weapon.Blueprint.Double) return false;
                ItemEntityShield shield = (weapon.HoldingSlot as HandSlot)?.PairSlot?.MaybeShield;
                if (shield is null) return false;
                if (shield.ArmorComponent.Blueprint.ProficiencyGroup == ArmorProficiencyGroup.Buckler) return true;
                else return false;
            }

            public void OnEventAboutToTrigger(RuleCalculateAttackBonusWithoutTarget evt)
            {
                if (evt.Initiator != Owner) return;
                ItemEntityWeapon weapon = evt.Weapon;
                if (!CanBeUsedOn(weapon)) return;
                if (!weapon.HoldInTwoHands) return;
                BlueprintWeaponType type = weapon.Blueprint.Type;

                if (type.Category != WeaponCategory.Longbow
                    && type.Category != WeaponCategory.HeavyCrossbow
                    && type.Category != WeaponCategory.LightCrossbow
                    && type.Category != WeaponCategory.HandCrossbow
                    && type.Category != WeaponCategory.HeavyRepeatingCrossbow
                    && type.Category != WeaponCategory.LightRepeatingCrossbow
                    && !Owner.Ensure<MechanicsFeatureExtension.MechanicsFeatureExtensionPart>().UnhinderingShield)
                { evt.AddModifier(-1, Fact, ModifierDescriptor.Penalty); }
            }

            public void OnEventDidTrigger(RuleCalculateAttackBonusWithoutTarget evt) { }
            public void OnEventAboutToTrigger(RuleAttackWithWeapon evt)
            {
                if (evt.Weapon.HoldInTwoHands && evt.IsFirstAttack && Owner.Get<MechanicsFeatureExtension.MechanicsFeatureExtensionPart>()?.UnhinderingShield) Owner.AddBuff(ShieldForbiddance, Fact.MaybeContext, new TimeSpan?(new Rounds(1).Seconds));
            }
            public void OnEventDidTrigger(RuleAttackWithWeapon evt) { }

            [HarmonyPatch(typeof(BlueprintsCache), nameof(BlueprintsCache.Init))]
            public static class CachePatch
            {

                [HarmonyPrepare]
                public static bool Prepare()
                {

                    if (Settings.IsEnabled("AllowTwoHanded-as-OneHandedWhenBuckler")) return true;
                    else { Comment.Log("AllowTwoHanded-as-OneHandedWhenBuckler setting is disabled, patch AddBuckler1hToProfficiencyBlueprint won't be applied."); return false; };
                }
                [HarmonyPostfix]
                public static void AddBuckler1hToBlueprint()
                {
                    Comment.Log("Entered cache postfix to add Buckler1h component");
                    #region create 1h feature
                    BlueprintFeature Buckler1h_blueprint = new()
                    {
                        AssetGuid = new(new Guid("eb322fe21ec64a928ace4eaedb6d4339")),
                        name = "Buckler1h_Feature",
                        m_DisplayName = new LocalizedString() { Key = "Buckler1h_Name" },
                        HideInCharacterSheetAndLevelUp = true
                    };
                    Buckler1h_blueprint.AddComponent(new Buckler1h_Component());
                    ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(Buckler1h_blueprint.AssetGuid, Buckler1h_blueprint);
                    Comment.Log("Added Buckler1h feature to the cache");

                    #endregion
                    if (!RetrieveBlueprint("ca22afeb94442b64fb8536e7a9f7dc11", out BlueprintFeature FightDefensively, "FightDefensively", "when adding Buckler_1h to it")) return;
                    if (FightDefensively.Components.First(component => component is AddFacts) is not AddFacts AF)
                    {
                        Comment.Warning("Failed to find AddFacts component on the FightDefensively feature blueprint. Can not add Buckler1h component.");
                        return;
                    };
                    AF.m_Facts = AF.m_Facts.Append(Buckler1h_blueprint.ToReference<BlueprintUnitFactReference>()).ToArray();

                    BlueprintShieldType BucklerType = ResourcesLibrary.TryGetBlueprint<BlueprintShieldType>("26fcc43f7d20374498d2e1643381d345");
                    BucklerType.m_TypeNameText = new LocalizedString() { Key = "Buckler_Description" };
                }
            }
        }
        //public class ForbidShield : UnitFactComponentDelegate, ITargetRulebookHandler<RuleCalculateAC>
        //{
        //    public void OnEventAboutToTrigger(RuleCalculateAC evt)
        //    {
        //        evt.SetCustomData(Backstab.ShieldBonusACDenied, true);
        //        //Main.Comment.Log("Set ShieldBonusACDenied for " + evt.Target.CharacterName);
        //    }
        //    public void OnEventDidTrigger(RuleCalculateAC evt) { }
        //}

        [HarmonyPatch(typeof(BlueprintsCache), nameof(BlueprintsCache.Init))]
        [HarmonyPostfix]
        public static void AddBucklerParryToBucklerProfficiencyBlueprint()
        {
            #region Create Shield Forbiddance blueprint
            BlueprintBuff ShieldForbiddance = new()
            {
                AssetGuid = new BlueprintGuid(new Guid("414f40680af64050a2a9dde3dede32ac")),
                name = "ForbidShieldACforOneTurn",
                FxOnRemove = new(),
                m_Flags = BlueprintBuff.Flags.HiddenInUi,
            };
            ShieldForbiddance.AddComponent(new AddMechanicsFeature() { m_Feature = MechanicsFeatureExtension.ShieldDenied });
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(ShieldForbiddance.AssetGuid, ShieldForbiddance);
            Buckler1h_Component.ShieldForbiddance = ShieldForbiddance;
            #endregion
            #region Create BucklerParryBuff
            Comment.Log("Begin creating the BucklerParryBuff blueprint.");
            BlueprintBuff BucklerParryBuff = new()
            {
                AssetGuid = new BlueprintGuid(new Guid("a8f2b254bc2e4f8b95e12aa444287c58")),
                name = "BucklerParryBuff",
                m_Flags = BlueprintBuff.Flags.StayOnDeath,
                m_DisplayName = new LocalizedString() { Key = "BucklerParry_DisplayName" },
                m_Description = new LocalizedString() { Key = "BucklerParry_Description" },
                m_DescriptionShort = new LocalizedString() { Key = "BucklerParry_ShortDescription" },
                Stacking = StackingType.Ignore,
                m_Icon = ResourcesLibrary.TryGetBlueprint<BlueprintShieldType>("26fcc43f7d20374498d2e1643381d345").Icon, //temporary
                FxOnRemove = ResourcesLibrary.TryGetBlueprint<BlueprintBuff>("6ffd93355fb3bcf4592a5d976b1d32a9").FxOnRemove
            };
            BucklerParryBuff.AddComponent(new OffHandParry.OffHandParryComponent() { category = WeaponCategory.WeaponLightShield });
            //BucklerParryBuff.AddComponent(new AddMechanicsFeature() { m_Feature = MechanicsFeatureExtension.ShieldDenied });
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(BucklerParryBuff.AssetGuid, BucklerParryBuff);
            #endregion
            #region Create BucklerParryActivatableAbility
            BlueprintActivatableAbility BucklerParryActivatableAbility = new()
            {
                AssetGuid = new BlueprintGuid(new Guid("a86db1a253d0446b857938314af1ae51")),
                name = "BucklerParryActivatableAbility",
                m_Buff = BucklerParryBuff.ToReference<BlueprintBuffReference>(),
                ActivationType = AbilityActivationType.OnUnitAction,
                m_ActivateOnUnitAction = AbilityActivateOnUnitActionType.Attack,
                DeactivateAfterFirstRound = true,
                m_DisplayName = new LocalizedString() { Key = "BucklerParry_DisplayName" },
                m_Description = new LocalizedString() { Key = "BucklerParry_Description" },
                m_DescriptionShort = new LocalizedString() { Key = "BucklerParry_ShortDescription" },
                DoNotTurnOffOnRest = true,
                m_Icon = ResourcesLibrary.TryGetBlueprint<BlueprintItemShield>("78aef04821150bd479314bc974ea73e2").m_Icon
            };
            BucklerParryActivatableAbility.AddComponent(new ShieldEquippedRestriction());
            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(BucklerParryActivatableAbility.AssetGuid, BucklerParryActivatableAbility);
            #endregion
            if (Settings.IsDisabled("AddBucklerParry")) return;
            #region modify Buckler Proficiency blueprint
            BlueprintFeature BucklerProf = ResourcesLibrary.TryGetBlueprint<BlueprintFeature>("7c28228ce4eed1543a6b670fd2a88e72");
            if (BucklerProf is null) { Main.Comment.Log("Failed to find BucklerProficiency blueprint when adding BucklerParry"); }
            BucklerProf.AddComponent(new AddFacts()
            {
                m_Facts = new BlueprintUnitFactReference[] { BucklerParryActivatableAbility.ToReference<BlueprintUnitFactReference>() }
            });
            #endregion
            #region modify Light Shield Proficiency blueprint
            BlueprintFeature ShieldsProf = ResourcesLibrary.TryGetBlueprint<BlueprintFeature>("cb8686e7357a68c42bdd9d4e65334633");
            if (ShieldsProf is null) { Main.Comment.Log("Failed to find ShieldsProficiency blueprint when adding BucklerParry"); }
            ShieldsProf.AddComponent(new AddFacts()
            {
                m_Facts = new BlueprintUnitFactReference[] { BucklerParryActivatableAbility.ToReference<BlueprintUnitFactReference>() }
            });
            #endregion
        }

        public class ShieldEquippedRestriction : ActivatableAbilityRestriction
        {
            public override bool IsAvailable()
            {
                UnitBody body = Owner?.Body;
                if (body is null) return false;
                ItemEntityWeapon mainhand = body.PrimaryHand.MaybeWeapon;
                if (mainhand is not null && mainhand.HoldInTwoHands) return false;
                ItemEntityShield shield = body.SecondaryHand?.MaybeShield;
                if (shield is null || shield.WeaponComponent is null || shield.ArmorComponent is null) return false;
                if (shield.WeaponComponent.Blueprint.Category == WeaponCategory.WeaponLightShield
                    && Owner.Proficiencies.Contains(shield.ArmorComponent.Blueprint.ProficiencyGroup)) return true;
                else return false;
            }
        }
    }
}
