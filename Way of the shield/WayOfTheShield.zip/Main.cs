﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;
using Kingmaker.Modding;
using Owlcat.Runtime.Core.Logging;
using UnityModManagerNet;
using UnityEngine;
using System.Drawing;
using Kingmaker.Items;

namespace Way_of_the_shield
{
    [EnableReloading]
    public static class Main
    {

        public static LogChannel Comment;
        public static string modName = "";
        public static object mod;
        public static string modPath;
        static bool BeenLoaded = false;
        internal static Assembly[] allAssemblies;
        internal static Assembly UMM;
        internal static Assembly TTTCore;
        internal static Assembly TTTBase;

        [OwlcatModificationEnterPoint]
        public static void LoadOwlcat(OwlcatModification modEntry)
        {
            mod = modEntry;
            if (!BeenLoaded)
            {
                Comment = modEntry.Logger;
                modName = modEntry.Manifest.UniqueName;
                modPath = modEntry.Path;
            }
            Load();
        }

        public static void Load(UnityModManager.ModEntry modEntry)
        {
            mod = modEntry;
            if (!BeenLoaded)
            {
                Comment = LogChannelFactory.GetOrCreate(modEntry.Info.DisplayName);
                modName = modEntry.Info.Id;
                modPath = modEntry.Path;
            }
            Load();
        }


        public static void Load()
        {

            Comment.Log(modName);
            #region get assemblies
            allAssemblies = AppDomain.CurrentDomain.GetAssemblies();
            UMM = allAssemblies.Where(a => a.FullName.Contains("UnityModManager")).FirstOrDefault();
            if (UMM != null)
            {
                TTTCore = CheckForMod("TabletopTweaks-Core");
                TTTBase = CheckForMod("TabletopTweaks-Base");
            }
            #endregion
            Comment.Log("TTT-Core is " + TTTCore?.FullName ?? null);
            Comment.Log("TTT-Base is " + TTTBase?.FullName ?? null);
            if (Settings.initialized == false) Settings.Init();
            Harmony harmony = new(modName);
            //if (mod is UnityModManager.ModEntry modEntry)
            //{


            //};
            harmony.PatchAll();
            Comment.Log("Patched things up.");
            BeenLoaded = true;
            ModifierDescriptorComparer.Instance = new();
        }

        

        public static Assembly CheckForMod(string modName)
        {
            return allAssemblies.Where(ass => ass.FullName.Contains(modName)).FirstOrDefault();
        }
    }

    [HarmonyPatch(typeof(BlueprintsCache), nameof(BlueprintsCache.Init))]
    public static class LocalizationPatchForUMM
    {
        [HarmonyPrepare]
        public static bool UMMCheck()
        {
            if (Main.mod is OwlcatModification) return false;
            else return true;
        }

        [HarmonyPrefix]
        public static void Prefix()
        {
            try
            {
                Main.Comment.Log("Will try to apply localization for the " + LocalizationManager.CurrentLocale + " locale.");
                LocalizationPack localizationPack = LocalizationManager.LoadPack(Main.modPath + Path.DirectorySeparatorChar + "Localization" + Path.DirectorySeparatorChar + LocalizationManager.CurrentLocale + ".json", LocalizationManager.CurrentLocale);
                LocalizationPack currentPack = LocalizationManager.CurrentPack;
                if (localizationPack != null && currentPack != null)
                {
                    currentPack.AddStrings(localizationPack);
                    Main.Comment.Log("Applied localization for the " + LocalizationManager.CurrentLocale + "locale.");
                }
                else Main.Comment.Error("Failed to apply the localization. LocalizationPack is null? " + (localizationPack is null) + ". CurrentPack is null?" + (currentPack is null) + ".");
            }
            catch
            {
                Main.Comment.Error("Failed to apply the localization");
            };
        }
    }
    [HarmonyPatch(typeof(OwlcatModification), nameof(OwlcatModification.TryLoadBundle))]
    public static class DumbBundleFix
    {
        [HarmonyPrefix]
        public static bool Fix(OwlcatModification __instance, string bundleName, ref AssetBundle __result)
        {
            if (!__instance.Settings.BundlesLayout.GuidToBundle.Values.Contains(bundleName))
                __result = null;
            else __result = __instance.LoadBundle(bundleName);
            return false;
        }
    }
}
