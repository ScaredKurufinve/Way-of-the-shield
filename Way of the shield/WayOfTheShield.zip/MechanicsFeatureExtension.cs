﻿using Kingmaker.EntitySystem;
using Kingmaker.UnitLogic.FactLogic;
namespace Way_of_the_shield
{
    [HarmonyPatch]
    public static class MechanicsFeatureExtension
    {
        public const AddMechanicsFeature.MechanicsFeatureType UnhinderingShield = (AddMechanicsFeature.MechanicsFeatureType)3000;
        public const AddMechanicsFeature.MechanicsFeatureType TowerShieldDefense = (AddMechanicsFeature.MechanicsFeatureType)3001;
        public const AddMechanicsFeature.MechanicsFeatureType ForceOneHanded = (AddMechanicsFeature.MechanicsFeatureType)3002;
        public const AddMechanicsFeature.MechanicsFeatureType BucklerBash = (AddMechanicsFeature.MechanicsFeatureType)3003;
        public const AddMechanicsFeature.MechanicsFeatureType ShieldDenied = (AddMechanicsFeature.MechanicsFeatureType)3004;
        public const AddMechanicsFeature.MechanicsFeatureType ForceDualWieldingPenalties = (AddMechanicsFeature.MechanicsFeatureType)3005;


        public class MechanicsFeatureExtensionPart : EntityPart
        {
            public CountableFlag UnhinderingShield = new();
            public CountableFlag TowerShieldBrace = new();
            public CountableFlag ForceOneHanded = new();
            public CountableFlag BucklerBash = new();
            public CountableFlag ShieldDenied = new();
            public CountableFlag ForceDualWieldingPenalties = new();
        }


        [HarmonyPatch(typeof(AddMechanicsFeature.Runtime), nameof(AddMechanicsFeature.Runtime.GetFeature))]
        [HarmonyPrefix]
        public static bool Prefix(ref CountableFlag __result, UnitEntityData unit, AddMechanicsFeature.MechanicsFeatureType type)
        {
            if (Settings.IsEnabled("Debug")) Main.Comment.Log("Entered AddMechanicsFeature.Runtime.GetFeature prefix");
            if (type < UnhinderingShield) return true;
            MechanicsFeatureExtensionPart features = unit.Ensure<MechanicsFeatureExtensionPart>();
            __result = type switch
            {
                UnhinderingShield => features.UnhinderingShield,
                TowerShieldDefense => features.TowerShieldBrace,
                ForceOneHanded => features.ForceOneHanded,
                BucklerBash => features.BucklerBash,
                ShieldDenied => features.ShieldDenied,
                ForceDualWieldingPenalties => features.ForceDualWieldingPenalties,
                _ => null
            };
            if (Settings.IsEnabled("Debug")) Main.Comment.Log("Mechanics feature = " + (int)type);
            if (__result is null) return true;
            else return false;


        }


    }
}
